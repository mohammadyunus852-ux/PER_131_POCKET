# PocketSmart AI

### Smart Budget Planning & AI Recommendations
> *"Your budget, turned into a plan."*

PocketSmart AI is a full-stack, budget-aware AI recommendation platform featuring three specialized planning verticals:
1. **Home Interior Planner** — Room-by-room furniture, lighting, decor, and modular storage plans.
2. **Party / Event Planner** — Guest-scaled catering, venue setup, decoration, and entertainment allocations.
3. **Jewelry Planner** — Occasion, metal, and outfit-color matching with optional privacy-preserving outfit image analysis.

---

## Features

- **Complete Authentication**: User registration, duplicate email protection, minimum 8-character password validation, `bcrypt` password hashing, and `HttpOnly` JWT session cookies (never stored in `localStorage`).
- **Gemini AI + Deterministic Local Fallback**:
  - Uses the official `@google/genai` / `google-genai` SDK with structured JSON schema output and configurable `GEMINI_MODEL` (default `gemini-3.8-flash`).
  - Automatically falls back to a deterministic local recommendation engine (`Local Fallback`) when `GEMINI_API_KEY` is not configured or if the upstream service is unreachable.
- **Strict Budget Ceiling Control**: Validates and normalizes all item recommendations and allocations so `estimated_total <= budget` is always preserved, returning `Budget`, `Estimated Total`, and `Remaining Budget`.
- **Dynamic Marketplace Search Destinations**: Generates safe search links for `Amazon`, `Flipkart`, `IKEA`, `Swiggy`, `Zomato`, and `OYO` (with a Google Search fallback for unrecognized platforms) without claiming live inventory verification.
- **Outfit Image Analysis (Privacy-Preserving)**: Accepts `JPEG`, `PNG`, and `WebP` uploads up to `5 MB` for Jewelry planning, analyzing only visible colors and style cues without identifying individuals.
- **Per-User SQLite History**: Stores user accounts and generated recommendations in SQLite (`pocketsmart.db`) with strict user ownership checks.

---

## Architecture & Technology Stack

- **Frontend**: Responsive HTML5, Tailwind CSS, TypeScript / React SPA + Vanilla JS static bundle in `frontend/`
- **Backend**:
  - **Google AI Studio Live Runtime**: Node.js / Express + TypeScript (`server.ts`, `src/server/app.ts`) running on port `3000` with SQLite (`pocketsmart.db`), `bcryptjs`, `jsonwebtoken`, `cookie-parser`, `multer`, and `@google/genai`.
  - **Python / FastAPI Reference Runtime**: FastAPI + Uvicorn + Pydantic + SQLite (`app/main.py`).
- **Database**: SQLite (`pocketsmart.db`) with `users` and `recommendations` tables linked by `FOREIGN KEY (user_id) REFERENCES users(id)`.

---

## Environment Setup

Copy `.env.example` to `.env` and configure your environment variables:

```env
APP_NAME=PocketSmart AI
APP_ENV=development
SECRET_KEY=change-this-to-a-long-random-secret
DATABASE_URL=sqlite:///./pocketsmart.db
GEMINI_API_KEY=
GEMINI_MODEL=gemini-3.8-flash
ACCESS_TOKEN_EXPIRE_MINUTES=1440
MAX_UPLOAD_MB=5
```

- If `GEMINI_API_KEY` is set, the planner status badge displays `AI: [MODEL NAME]` (`Gemini AI`).
- If `GEMINI_API_KEY` is omitted, the application runs seamlessly in `AI: Local Fallback` mode.

---

## Running the Server

### Google AI Studio / Node.js Full-Stack Runtime
```bash
npm install
npm run dev
```
- Application: `http://localhost:3000`

### Python / FastAPI Runtime
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```
- Application: `http://127.0.0.1:8000`
- API Documentation: `http://127.0.0.1:8000/docs`

---

## API Documentation

### Authentication
- `POST /api/auth/register` — Register a new user (`email`, `password`, `confirm_password`) and set `HttpOnly` JWT cookie.
- `POST /api/auth/login` — Authenticate (`email`, `password`) and set `HttpOnly` JWT cookie.
- `POST /api/auth/token` — OAuth2-compatible login endpoint.
- `POST /api/auth/logout` — Clear authentication cookie.
- `GET /api/auth/me` — Get current authenticated user.

### Session & System
- `GET /api/session-info` — Current auth state & AI mode (`Gemini AI` or `Local Fallback`).
- `GET /api/session-data` — Current user & saved recommendation count.
- `GET /api/startup` — Startup configuration & model readiness.
- `GET /health` — Health check endpoint.

### Planners
- `POST /api/generate-home` — Generate Home Interior budget plan.
- `POST /api/generate-party` — Generate Party / Event budget plan.
- `POST /api/generate-jewelry` — Generate Jewelry budget plan (`multipart/form-data` with optional `outfit_image` or JSON).

### History
- `GET /api/history` — Retrieve current user's saved recommendations.
- `GET /api/recommendations-details/{recommendation_id}` — Retrieve full details for a single saved recommendation (enforces user ownership).

---

## Testing

Run the automated API & schema test suite:

```bash
npx tsx tests/run_tests.ts
```

Or with `pytest` in a Python environment:
```bash
pytest
```
