import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/server/app.ts';
import { enforceBudgetControl } from '../src/server/catalog.ts';
import { db } from '../src/server/db.ts';

async function runTests() {
  db.resetForTests();
  const app = createApp();
  const server = http.createServer(app);

  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${address.port}`;

  console.log(`Running PocketSmart AI Test Suite against ${baseUrl}...`);

  try {
    // 1. Health & Startup endpoints
    {
      const res = await fetch(`${baseUrl}/health`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.status, 'ok');
      assert.equal(data.app, 'PocketSmart AI');

      const startRes = await fetch(`${baseUrl}/api/startup`);
      assert.equal(startRes.status, 200);
      const startData = await startRes.json();
      assert.equal(startData.app_name, 'PocketSmart AI');
      console.log('✓ 1. Health & Startup endpoints passed');
    }

    // 2. Registration & Auto-Login Cookie
    let user1Cookie = '';
    {
      const res = await fetch(`${baseUrl}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'alice@pocketsmart.ai',
          password: 'Password123!',
          confirm_password: 'Password123!',
        }),
      });
      assert.equal(res.status, 201);
      const setCookie = res.headers.get('set-cookie') || '';
      assert.ok(setCookie.includes('access_token='), 'Must set HttpOnly access_token cookie');
      assert.ok(setCookie.toLowerCase().includes('httponly'), 'Cookie must be HttpOnly');
      user1Cookie = setCookie.split(';')[0];
      console.log('✓ 2. Registration & HttpOnly cookie passed');
    }

    // 3. Duplicate registration prevention
    {
      const res = await fetch(`${baseUrl}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'alice@pocketsmart.ai',
          password: 'Password123!',
          confirm_password: 'Password123!',
        }),
      });
      assert.equal(res.status, 409);
      const data = await res.json();
      assert.equal(data.detail, 'An account with this email already exists.');
      console.log('✓ 3. Duplicate registration prevention passed');
    }

    // 4. Login & Session endpoints
    {
      const res = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'alice@pocketsmart.ai',
          password: 'Password123!',
        }),
      });
      assert.equal(res.status, 200);
      const setCookie = res.headers.get('set-cookie') || '';
      user1Cookie = setCookie.split(';')[0];

      const meRes = await fetch(`${baseUrl}/api/auth/me`, {
        headers: { Cookie: user1Cookie },
      });
      assert.equal(meRes.status, 200);
      const meData = await meRes.json();
      assert.equal(meData.email, 'alice@pocketsmart.ai');

      const sessRes = await fetch(`${baseUrl}/api/session-info`, {
        headers: { Cookie: user1Cookie },
      });
      assert.equal(sessRes.status, 200);
      const sessData = await sessRes.json();
      assert.equal(sessData.authenticated, true);
      console.log('✓ 4. Login & Session endpoints passed');
    }

    // 5. Home planner validation & generation
    let aliceRecId = 0;
    {
      const badRes = await fetch(`${baseUrl}/api/generate-home`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Cookie: user1Cookie,
        },
        body: JSON.stringify({
          budget: 100,
          room_types: [],
          style: 'modern',
        }),
      });
      assert.equal(badRes.status, 422);

      const goodRes = await fetch(`${baseUrl}/api/generate-home`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Cookie: user1Cookie,
        },
        body: JSON.stringify({
          budget: 100000,
          room_types: ['Living Room', 'Bedroom'],
          items: {},
          style: 'modern',
          city: 'India',
          notes: 'Compact sofa and warm lighting',
        }),
      });
      assert.equal(goodRes.status, 200);
      const plan = await goodRes.json();
      assert.ok(plan.estimated_total <= 100000, 'Estimated total must not exceed budget');
      assert.equal(plan.remaining_budget, 100000 - plan.estimated_total);
      assert.ok(Array.isArray(plan.recommendations) && plan.recommendations.length > 0);
      assert.ok(plan.recommendations[0].search_url.startsWith('https://'));
      aliceRecId = Number(plan.id);
      console.log('✓ 5. Home planner validation & budget enforcement passed');
    }

    // 6. Party planner validation & generation
    {
      const badRes = await fetch(`${baseUrl}/api/generate-party`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Cookie: user1Cookie,
        },
        body: JSON.stringify({
          budget: 50000,
          guests: 0,
          event_type: 'birthday',
          venue: 'home',
          food_preference: 'mixed',
        }),
      });
      assert.equal(badRes.status, 422);

      const goodRes = await fetch(`${baseUrl}/api/generate-party`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Cookie: user1Cookie,
        },
        body: JSON.stringify({
          budget: 50000,
          guests: 30,
          event_type: 'birthday',
          venue: 'home',
          city: 'India',
          food_preference: 'mixed',
          notes: '',
        }),
      });
      assert.equal(goodRes.status, 200);
      const plan = await goodRes.json();
      assert.ok(plan.estimated_total <= 50000);
      console.log('✓ 6. Party planner validation & generation passed');
    }

    // 7. Jewelry planner multipart/form-data & image validation
    {
      const badForm = new FormData();
      badForm.append('budget', '25000');
      badForm.append('occasion', 'wedding');
      badForm.append('style', 'elegant');
      badForm.append(
        'outfit_image',
        new Blob(['not an image'], { type: 'text/plain' }),
        'invalid.txt'
      );

      const badRes = await fetch(`${baseUrl}/api/generate-jewelry`, {
        method: 'POST',
        headers: { Cookie: user1Cookie },
        body: badForm,
      });
      assert.equal(badRes.status, 415);

      const goodForm = new FormData();
      goodForm.append('budget', '25000');
      goodForm.append('occasion', 'wedding');
      goodForm.append('style', 'elegant');
      goodForm.append('outfit_color', 'Emerald Green');
      goodForm.append('metal_preference', 'gold');

      const goodRes = await fetch(`${baseUrl}/api/generate-jewelry`, {
        method: 'POST',
        headers: { Cookie: user1Cookie },
        body: goodForm,
      });
      assert.equal(goodRes.status, 200);
      const plan = await goodRes.json();
      assert.ok(plan.estimated_total <= 25000);
      console.log('✓ 7. Jewelry planner validation & multipart upload passed');
    }

    // 8. Budget control scaling unit test (overshoot normalization)
    {
      const normalized = enforceBudgetControl(
        {
          title: 'Overshoot Test Plan',
          summary: 'Testing normalization when raw items exceed budget',
          allocations: [{ label: 'Furniture', amount: 90000 }],
          recommendations: [
            {
              category: 'Furniture',
              name: 'Luxury Sofa',
              estimated_price: 60000,
              platform: 'IKEA',
              rationale: 'Test',
            },
            {
              category: 'Lighting',
              name: 'Chandelier',
              estimated_price: 40000,
              platform: 'Amazon',
              rationale: 'Test',
            },
          ],
          tips: ['Tip 1', 'Tip 2', 'Tip 3'],
        },
        50000,
        'home',
        'Local Fallback',
        'Local Fallback'
      );
      assert.ok(
        normalized.estimated_total <= 50000,
        `Normalized total ${normalized.estimated_total} must be <= 50000`
      );
      assert.equal(normalized.remaining_budget, 50000 - normalized.estimated_total);
      console.log('✓ 8. Recommendation budget scaling & ceiling control passed');
    }

    // 9. History & Cross-User Authorization isolation
    {
      const histRes = await fetch(`${baseUrl}/api/history`, {
        headers: { Cookie: user1Cookie },
      });
      assert.equal(histRes.status, 200);
      const histData = await histRes.json();
      assert.equal(histData.items.length, 3);

      // Register second user Bob
      const bobReg = await fetch(`${baseUrl}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'bob@pocketsmart.ai',
          password: 'Password123!',
          confirm_password: 'Password123!',
        }),
      });
      const bobCookie = (bobReg.headers.get('set-cookie') || '').split(';')[0];

      // Bob should NOT be able to view Alice's recommendation
      const unauthorizedDetail = await fetch(
        `${baseUrl}/api/recommendations-details/${aliceRecId}`,
        {
          headers: { Cookie: bobCookie },
        }
      );
      assert.equal(unauthorizedDetail.status, 403);

      // Alice CAN view her own recommendation
      const authorizedDetail = await fetch(
        `${baseUrl}/api/recommendations-details/${aliceRecId}`,
        {
          headers: { Cookie: user1Cookie },
        }
      );
      assert.equal(authorizedDetail.status, 200);
      console.log('✓ 9. History retrieval & cross-user authorization isolation passed');
    }

    // 10. Logout
    {
      const logoutRes = await fetch(`${baseUrl}/api/auth/logout`, {
        method: 'POST',
        headers: { Cookie: user1Cookie },
      });
      assert.equal(logoutRes.status, 200);
      console.log('✓ 10. Logout endpoint passed');
    }

    console.log('\nALL POCKETSMART AI TESTS PASSED SUCCESSFULLY!');
  } finally {
    db.resetForTests();
    server.close();
  }
}

runTests().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
