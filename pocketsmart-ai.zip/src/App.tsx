import { useEffect, useState } from 'react';
import { DashboardView } from './components/DashboardView';
import { HistoryView } from './components/HistoryView';
import { Navbar } from './components/Navbar';
import { PlannersView } from './components/PlannersView';
import {
  AppView,
  PlannerType,
  SessionInfo,
} from './types/pocketsmart';

const DEFAULT_SESSION: SessionInfo = {
  authenticated: true,
  user: null,
  ai_configured: false,
  ai_mode: 'Local Fallback',
  model: 'Local Fallback',
};

export default function App() {
  const [session, setSession] = useState<SessionInfo>(DEFAULT_SESSION);
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [activePlannerTab, setActivePlannerTab] = useState<PlannerType>('home');

  useEffect(() => {
    fetch('/api/session-info', { credentials: 'include' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: SessionInfo | null) => {
        if (data) setSession(data);
      })
      .catch(() => {
        // Fallback if offline
      });
  }, []);

  const handleSelectPlanner = (planner: PlannerType) => {
    setActivePlannerTab(planner);
    setCurrentView('planners');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (view: AppView) => {
    setCurrentView(view === 'auth' ? 'dashboard' : view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div id="top" className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#0F172A]">
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      <main className="flex-1 max-w-[1280px] w-full mx-auto px-6 py-8">
        {currentView === 'dashboard' ? (
          <DashboardView
            session={session}
            onSelectPlanner={handleSelectPlanner}
            onViewHistory={() => handleNavigate('history')}
          />
        ) : currentView === 'planners' ? (
          <PlannersView
            session={session}
            activeTab={activePlannerTab}
            onTabChange={setActivePlannerTab}
            onViewHistory={() => handleNavigate('history')}
          />
        ) : (
          <HistoryView
            onStartPlanning={() => handleNavigate('planners')}
          />
        )}
      </main>

      <footer className="border-t border-slate-200 bg-white py-6 px-6 text-xs text-slate-500">
        <div className="max-w-[1280px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <strong className="text-slate-800">PocketSmart AI</strong> · Your budget, turned into a plan.
          </div>
          <div className="flex items-center gap-4">
            <span>
              AI Engine:{' '}
              <strong className="text-slate-700">
                {session.ai_configured ? `Gemini AI (${session.model})` : 'Local Fallback'}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <a
              href="/docs"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-900 hover:underline"
            >
              API Docs
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
