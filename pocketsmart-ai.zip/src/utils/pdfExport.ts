import { jsPDF } from 'jspdf';
import { ComicStory } from '../types/comic';

/**
 * Converts any image data URL (including data:image/svg+xml, PNG, or JPEG)
 * into a standard raster JPEG data URL via an HTML5 Canvas so jsPDF can embed it reliably.
 */
async function rasterizeImageForPdf(dataUrl: string | undefined): Promise<string | null> {
  if (!dataUrl) return null;

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 960;
        canvas.height = 540;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(null);
          return;
        }
        ctx.fillStyle = '#18181B';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.9));
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}

export async function exportComicToPdf(story: ComicStory): Promise<void> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;

  const drawPageBackground = () => {
    doc.setFillColor(244, 244, 240); // #F4F4F0 warm paper
    doc.rect(0, 0, pageWidth, pageHeight, 'F');
    // Subtle outer comic page rule
    doc.setDrawColor(24, 24, 27);
    doc.setLineWidth(0.5);
    doc.rect(8, 8, pageWidth - 16, pageHeight - 16, 'S');
  };

  drawPageBackground();

  // Header Banner on Page 1
  doc.setFillColor(24, 24, 27);
  doc.rect(margin, 14, contentWidth, 24, 'F');

  doc.setTextColor(225, 29, 72); // Cinnabar accent
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('COMICCRAFT · AI COMIC STORY CREATOR', margin + 6, 22);

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  const titleLines = doc.splitTextToSize(story.storyTitle.toUpperCase(), contentWidth - 12);
  doc.text(titleLines[0] || 'UNTITLED COMIC', margin + 6, 31);

  // Story Metadata Row
  let cursorY = 44;
  doc.setTextColor(63, 63, 70);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  const metaLine = `CHARACTER: ${story.input.characterName}   ·   SETTING: ${story.input.setting}   ·   TONE: ${story.input.tone}   ·   STYLE: ${story.input.artStyle}`;
  doc.text(metaLine, margin, cursorY);

  cursorY += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(82, 82, 91);
  const profileLines = doc.splitTextToSize(
    `Character Profile: ${story.characterProfile.summary}`,
    contentWidth
  );
  doc.text(profileLines, margin, cursorY);
  cursorY += profileLines.length * 4 + 4;

  // Divider line
  doc.setDrawColor(24, 24, 27);
  doc.setLineWidth(0.4);
  doc.line(margin, cursorY, pageWidth - margin, cursorY);
  cursorY += 6;

  // Render all 5 panels across pages (up to 2 panels per page for large legible art + dialogue)
  for (let i = 0; i < story.panels.length; i++) {
    const panel = story.panels[i];

    // Estimate required height for this panel block
    const imgHeight = 64; // 16:9 image height in mm
    const imgWidth = imgHeight * (16 / 9); // ~113.7mm

    if (cursorY + 105 > pageHeight - 16) {
      doc.addPage();
      drawPageBackground();
      cursorY = 16;
    }

    // Panel Header Bar
    doc.setFillColor(24, 24, 27);
    doc.rect(margin, cursorY, contentWidth, 8, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(
      `PANEL ${panel.panel_number}: ${panel.title.toUpperCase()} (${panel.narrative_stage.toUpperCase()})`,
      margin + 4,
      cursorY + 5.5
    );
    cursorY += 10;

    // Left column: Panel Illustration (114mm wide, 64mm tall)
    const rasterizedDataUrl = await rasterizeImageForPdf(panel.imageUrl);
    if (rasterizedDataUrl) {
      doc.addImage(rasterizedDataUrl, 'JPEG', margin, cursorY, imgWidth, imgHeight);
    } else {
      doc.setFillColor(39, 39, 42);
      doc.rect(margin, cursorY, imgWidth, imgHeight, 'F');
    }
    doc.setDrawColor(24, 24, 27);
    doc.setLineWidth(0.8);
    doc.rect(margin, cursorY, imgWidth, imgHeight, 'S');

    // Right column naast illustration: Scene Description & Narrator Box
    const rightColX = margin + imgWidth + 5;
    const rightColWidth = contentWidth - imgWidth - 5;
    let rightY = cursorY + 3;

    // Narrator Caption Box
    if (panel.narration) {
      const narLines = doc.splitTextToSize(`"${panel.narration}"`, rightColWidth - 6);
      const narBoxH = Math.min(narLines.length * 3.8 + 8, 32);
      doc.setFillColor(254, 243, 199); // Classic comic narrator parchment
      doc.setDrawColor(24, 24, 27);
      doc.setLineWidth(0.4);
      doc.rect(rightColX, rightY - 2, rightColWidth, narBoxH, 'FD');

      doc.setTextColor(146, 64, 14);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.text('NARRATOR', rightColX + 3, rightY + 2.2);

      doc.setTextColor(24, 24, 27);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.text(narLines.slice(0, 6), rightColX + 3, rightY + 6.5);
      rightY += narBoxH + 4;
    }

    // Scene Description
    doc.setTextColor(82, 82, 91);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text('SCENE:', rightColX, rightY);
    rightY += 3.5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.8);
    doc.setTextColor(39, 39, 42);
    const sceneLines = doc.splitTextToSize(panel.scene_description, rightColWidth);
    doc.text(sceneLines.slice(0, 8), rightColX, rightY);

    cursorY += imgHeight + 4;

    // Character Dialogue Bubbles below the illustration
    if (panel.dialogue && panel.dialogue.length > 0) {
      for (const line of panel.dialogue) {
        const speakerLabel = `${line.character.toUpperCase()}: `;
        const fullDialogue = `${speakerLabel}"${line.text}"`;
        const dlgLines = doc.splitTextToSize(fullDialogue, contentWidth - 8);
        const boxH = dlgLines.length * 4 + 4;

        if (cursorY + boxH > pageHeight - 14) {
          doc.addPage();
          drawPageBackground();
          cursorY = 16;
        }

        doc.setFillColor(255, 255, 255);
        doc.setDrawColor(24, 24, 27);
        doc.setLineWidth(0.4);
        doc.roundedRect(margin, cursorY, contentWidth, boxH, 2, 2, 'FD');

        doc.setTextColor(24, 24, 27);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8.2);
        doc.text(dlgLines, margin + 4, cursorY + 4.2);

        cursorY += boxH + 2.5;
      }
    }

    cursorY += 5;
  }

  // Sanitize filename
  const safeSlug =
    story.storyTitle
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'comiccraft-story';

  doc.save(`${safeSlug}-comiccraft.pdf`);
}
