import {
  ArtStyleOption,
  ComicInput,
  SettingOption,
  StoryToneOption,
} from '../types/comic';

export const SETTING_OPTIONS: SettingOption[] = [
  'Forest',
  'School',
  'City',
  'Space',
  'Fantasy World',
  'Cyberpunk Metropolis',
  'Underwater Kingdom',
  'Ancient Temple',
  'Steampunk Airship',
  'Cozy Village',
];

export const TONE_OPTIONS: StoryToneOption[] = [
  'Adventure',
  'Funny',
  'Dramatic',
  'Light-hearted',
  'Poetic',
  'Mystery',
  'Heroic',
  'Whimsical',
];

export const ART_STYLE_OPTIONS: ArtStyleOption[] = [
  'Comic Book',
  'Anime',
  'Cartoon',
  'Pixel Art',
  'Realistic',
  'Graphic Novel Noir',
  'Watercolor Storybook',
  'Retro Golden Age',
];

export interface StoryPreset {
  label: string;
  input: ComicInput;
}

export const STORY_PRESETS: StoryPreset[] = [
  {
    label: 'Enchanted Forest Door',
    input: {
      prompt:
        'A brave fox discovers a mysterious glowing door in an enchanted forest that only opens when a forgotten melody is hummed.',
      characterName: 'Luna',
      setting: 'Forest',
      tone: 'Adventure',
      artStyle: 'Comic Book',
    },
  },
  {
    label: 'Zero-Gravity Science Fair',
    input: {
      prompt:
        'During the annual orbital academy science fair, a student accidentally switches off the artificial gravity generator, sending every experiment floating through the halls.',
      characterName: 'Milo Vance',
      setting: 'Space',
      tone: 'Funny',
      artStyle: 'Anime',
    },
  },
  {
    label: 'The Clockwork Rooftop Chase',
    input: {
      prompt:
        'A young courier racing across rain-slicked city rooftops at midnight must protect a Brass Compass that points toward tomorrow instead of north.',
      characterName: 'Kaelen',
      setting: 'City',
      tone: 'Dramatic',
      artStyle: 'Graphic Novel Noir',
    },
  },
  {
    label: 'The Library of Floating Islands',
    input: {
      prompt:
        'An apprentice archivist journeys across sky-bridges between floating islands to return an overdue spellbook before its painted creatures wake up.',
      characterName: 'Seraphina',
      setting: 'Fantasy World',
      tone: 'Whimsical',
      artStyle: 'Watercolor Storybook',
    },
  },
];

export const MAX_PROMPT_LENGTH = 1200;
export const MIN_PROMPT_LENGTH = 12;
export const MAX_CHARACTER_NAME_LENGTH = 60;

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export function validateComicInput(input: ComicInput): ValidationResult {
  const trimmedPrompt = input.prompt.trim();
  const trimmedName = input.characterName.trim();

  if (!trimmedPrompt) {
    return {
      valid: false,
      error: 'Please enter a Story Prompt describing the main idea of your comic.',
    };
  }

  if (trimmedPrompt.length < MIN_PROMPT_LENGTH) {
    return {
      valid: false,
      error: `Your story prompt is a bit too brief. Please enter at least ${MIN_PROMPT_LENGTH} characters so we can craft a 5-panel arc.`,
    };
  }

  if (trimmedPrompt.length > MAX_PROMPT_LENGTH) {
    return {
      valid: false,
      error: `Story prompt is too long (${trimmedPrompt.length}/${MAX_PROMPT_LENGTH} characters). Please shorten it slightly.`,
    };
  }

  if (!trimmedName) {
    return {
      valid: false,
      error: 'Please enter a Main Character Name.',
    };
  }

  if (trimmedName.length > MAX_CHARACTER_NAME_LENGTH) {
    return {
      valid: false,
      error: `Main Character Name must be ${MAX_CHARACTER_NAME_LENGTH} characters or fewer.`,
    };
  }

  if (!input.setting) {
    return { valid: false, error: 'Please select a Setting for your story.' };
  }

  if (!input.tone) {
    return { valid: false, error: 'Please select a Story Tone.' };
  }

  if (!input.artStyle) {
    return { valid: false, error: 'Please select an Art Style.' };
  }

  return { valid: true };
}
