import { GoogleGenAI, Type } from '@google/genai';
import {
  enforceBudgetControl,
  RawPlanOutput,
  ValidatedPlanResponse,
} from './catalog.ts';
import {
  generateHomeFallback,
  generateJewelryFallback,
  generatePartyFallback,
  HomePlanRequest,
  JewelryPlanRequest,
  PartyPlanRequest,
} from './fallback.ts';

export const SYSTEM_INSTRUCTION = `You are PocketSmart AI, a careful budget planning assistant.

Generate practical budget-aware recommendations based on the user's inputs.

Return only valid structured JSON.

Never claim that you accessed a retailer's live inventory or current price unless such information was actually supplied.

Use estimated prices and clearly identify them as estimates.

Keep the estimated recommendation total at or below the user's requested budget.

Platforms such as Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO are recommendation/search destinations, not verified live listings.

Do not invent live product availability.

Provide useful, realistic, budget-conscious recommendations.`;

export function getGeminiStatus(): {
  configured: boolean;
  model: string;
  aiMode: 'Gemini AI' | 'Local Fallback';
} {
  const apiKey = process.env.GEMINI_API_KEY;
  const configured = Boolean(
    apiKey && apiKey.trim() !== '' && apiKey !== 'MY_GEMINI_API_KEY'
  );
  const model = (process.env.GEMINI_MODEL || 'gemini-3.8-flash').trim() || 'gemini-3.8-flash';
  return {
    configured,
    model,
    aiMode: configured ? 'Gemini AI' : 'Local Fallback',
  };
}

function createClient(): GoogleGenAI | null {
  const { configured } = getGeminiStatus();
  if (!configured) return null;
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const PLAN_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: 'Title of the budget plan.',
    },
    summary: {
      type: Type.STRING,
      description: 'Concise summary explaining how the budget is allocated and why.',
    },
    estimated_total: {
      type: Type.NUMBER,
      description: 'Total estimated cost in INR (must be <= requested budget).',
    },
    allocations: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          amount: { type: Type.NUMBER },
        },
        required: ['label', 'amount'],
      },
    },
    recommendations: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING },
          name: { type: Type.STRING },
          estimated_price: { type: Type.NUMBER },
          platform: {
            type: Type.STRING,
            description: 'One of Amazon, Flipkart, IKEA, Swiggy, Zomato, OYO',
          },
          rationale: { type: Type.STRING },
        },
        required: ['category', 'name', 'estimated_price', 'platform', 'rationale'],
      },
    },
    tips: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: '3 to 6 practical smart budget tips.',
    },
  },
  required: ['title', 'summary', 'estimated_total', 'allocations', 'recommendations', 'tips'],
};

function parseGeminiPlanJson(rawText: string | undefined): RawPlanOutput {
  if (!rawText || !rawText.trim()) {
    throw new Error('Empty Gemini response');
  }
  const cleaned = rawText
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();

  try {
    return JSON.parse(cleaned) as RawPlanOutput;
  } catch {
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start !== -1 && end > start) {
      return JSON.parse(cleaned.slice(start, end + 1)) as RawPlanOutput;
    }
    throw new Error('Malformed JSON from Gemini');
  }
}

export async function generateHomePlan(
  req: HomePlanRequest
): Promise<ValidatedPlanResponse> {
  const ai = createClient();
  const { model } = getGeminiStatus();

  if (!ai) {
    return generateHomeFallback(req);
  }

  try {
    const prompt = `Create a Home Interior budget plan in Indian Rupees (₹):
- Total Budget: ₹${req.budget}
- Rooms: ${req.room_types.join(', ')}
- Interior Style: ${req.style}
- City / Region: ${req.city || 'India'}
- Notes & Preferences: ${req.notes || 'None specified'}

Ensure the sum of recommendation estimated_price values is strictly at or below ₹${req.budget}. Use platforms such as IKEA, Amazon, and Flipkart.`;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.6,
        responseMimeType: 'application/json',
        responseSchema: PLAN_RESPONSE_SCHEMA,
      },
    });

    const parsed = parseGeminiPlanJson(response.text);
    return enforceBudgetControl(parsed, req.budget, 'home', 'Gemini AI', model);
  } catch (err) {
    console.warn('Gemini Home Planner error, falling back to Local Fallback:', err);
    return generateHomeFallback(req);
  }
}

export async function generatePartyPlan(
  req: PartyPlanRequest
): Promise<ValidatedPlanResponse> {
  const ai = createClient();
  const { model } = getGeminiStatus();

  if (!ai) {
    return generatePartyFallback(req);
  }

  try {
    const prompt = `Create a Party / Event budget plan in Indian Rupees (₹):
- Total Budget: ₹${req.budget}
- Number of Guests: ${req.guests}
- Event Type: ${req.event_type}
- Venue Type: ${req.venue}
- City / Region: ${req.city || 'India'}
- Food Preference: ${req.food_preference}
- Notes & Requirements: ${req.notes || 'None specified'}

Ensure the sum of recommendation estimated_price values is strictly at or below ₹${req.budget}. Use platforms such as Swiggy, Zomato, OYO, Amazon, and Flipkart.`;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.6,
        responseMimeType: 'application/json',
        responseSchema: PLAN_RESPONSE_SCHEMA,
      },
    });

    const parsed = parseGeminiPlanJson(response.text);
    return enforceBudgetControl(parsed, req.budget, 'party', 'Gemini AI', model);
  } catch (err) {
    console.warn('Gemini Party Planner error, falling back to Local Fallback:', err);
    return generatePartyFallback(req);
  }
}

export async function generateJewelryPlan(
  req: JewelryPlanRequest,
  outfitImage?: { buffer: Buffer; mimeType: string }
): Promise<ValidatedPlanResponse> {
  const ai = createClient();
  const { model } = getGeminiStatus();

  if (!ai) {
    return generateJewelryFallback({
      ...req,
      has_outfit_image: Boolean(outfitImage),
    });
  }

  try {
    const textPrompt = `Create a Jewelry budget plan in Indian Rupees (₹):
- Total Budget: ₹${req.budget}
- Occasion: ${req.occasion}
- Jewelry Style: ${req.style}
- Outfit Color: ${req.outfit_color || 'Not specified'}
- Metal Preference: ${req.metal_preference || 'Any'}
- Additional Notes: ${req.notes || 'None specified'}
${
  outfitImage
    ? 'An outfit image is attached. PRIVACY RULE: Only analyze visible colors, fabric/clothing style, and neckline/design cues to recommend matching jewelry. Never identify or describe any person.'
    : ''
}
Ensure the sum of recommendation estimated_price values is strictly at or below ₹${req.budget}. Use platforms such as Amazon and Flipkart.`;

    const contents = outfitImage
      ? {
          parts: [
            {
              inlineData: {
                mimeType: outfitImage.mimeType,
                data: outfitImage.buffer.toString('base64'),
              },
            },
            { text: textPrompt },
          ],
        }
      : textPrompt;

    const response = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.6,
        responseMimeType: 'application/json',
        responseSchema: PLAN_RESPONSE_SCHEMA,
      },
    });

    const parsed = parseGeminiPlanJson(response.text);
    return enforceBudgetControl(parsed, req.budget, 'jewelry', 'Gemini AI', model);
  } catch (err) {
    console.warn('Gemini Jewelry Planner error, falling back to Local Fallback:', err);
    return generateJewelryFallback({
      ...req,
      has_outfit_image: Boolean(outfitImage),
    });
  }
}
