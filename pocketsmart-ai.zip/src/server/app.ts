import bcrypt from 'bcryptjs';
import cookieParser from 'cookie-parser';
import express, { type NextFunction, type Request, type Response } from 'express';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import { db, type UserRecord } from './db.ts';
import {
  generateHomePlan,
  generateJewelryPlan,
  generatePartyPlan,
  getGeminiStatus,
} from './gemini.ts';

const SECRET_KEY = process.env.SECRET_KEY || 'pocketsmart-ai-super-secret-jwt-key-2026';
const ACCESS_TOKEN_EXPIRE_MINUTES = Number(process.env.ACCESS_TOKEN_EXPIRE_MINUTES) || 1440;
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB) || 5;
const MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024;
const ALLOWED_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const COOKIE_NAME = 'access_token';
const DEFAULT_GUEST_EMAIL = 'workspace@pocketsmart.ai';

interface JwtPayload {
  sub: string;
  user_id: number;
  email: string;
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_BYTES + 1024 * 1024 },
});

function createToken(user: UserRecord): string {
  return jwt.sign(
    {
      sub: String(user.id),
      user_id: user.id,
      email: user.email,
    },
    SECRET_KEY,
    { expiresIn: `${ACCESS_TOKEN_EXPIRE_MINUTES}m` }
  );
}

function setAuthCookie(res: Response, token: string): void {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: ACCESS_TOKEN_EXPIRE_MINUTES * 60 * 1000,
    path: '/',
  });
}

function getOrCreateDefaultUser(): UserRecord {
  const existing = db.getUserByEmail(DEFAULT_GUEST_EMAIL);
  if (existing) return existing;
  const hash = bcrypt.hashSync('PocketSmartDefaultPass123!', 8);
  return db.createUser(DEFAULT_GUEST_EMAIL, hash);
}

function resolveActiveUser(req: Request): UserRecord {
  let token = req.cookies?.[COOKIE_NAME];
  if (!token && req.headers.authorization?.startsWith('Bearer ')) {
    token = req.headers.authorization.slice(7).trim();
  }
  if (token) {
    try {
      const decoded = jwt.verify(token, SECRET_KEY) as JwtPayload;
      const user = db.getUserById(Number(decoded.user_id));
      if (user) return user;
    } catch {
      // fall through to default workspace user
    }
  }
  return getOrCreateDefaultUser();
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function createApp() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());

  // System & Health Endpoints
  app.get(['/health', '/api/health'], (_req: Request, res: Response) => {
    const gemini = getGeminiStatus();
    res.json({
      status: 'ok',
      app: process.env.APP_NAME || 'PocketSmart AI',
      ai_mode: gemini.aiMode,
      model: gemini.model,
      database: 'connected',
    });
  });

  app.get('/api/startup', (_req: Request, res: Response) => {
    const gemini = getGeminiStatus();
    res.json({
      app_name: 'PocketSmart AI',
      tagline: 'Your budget, turned into a plan.',
      status: 'ready',
      ai_configured: gemini.configured,
      ai_mode: gemini.aiMode,
      model: gemini.configured ? gemini.model : 'Local Fallback',
      configured_model: gemini.model,
      max_upload_mb: MAX_UPLOAD_MB,
    });
  });

  // API Docs endpoint
  app.get('/docs', (_req: Request, res: Response) => {
    res.type('html').send(`<!doctype html>
<html lang="en">
<head><meta charset="utf-8"/><title>PocketSmart AI — API Documentation</title>
<style>body{font-family:system-ui,sans-serif;max-width:880px;margin:40px auto;padding:0 20px;color:#0f172a;line-height:1.6}code{background:#f1f5f9;padding:2px 6px;border-radius:4px}</style>
</head>
<body>
  <h1>PocketSmart AI — REST API Documentation</h1>
  <p>Tagline: <em>Your budget, turned into a plan.</em></p>
  <ul>
    <li><code>GET /api/session-info</code> — Session & AI mode summary</li>
    <li><code>GET /api/session-data</code> — Session & saved recommendations count</li>
    <li><code>POST /api/generate-home</code> — Generate Home Interior budget plan</li>
    <li><code>POST /api/generate-party</code> — Generate Party / Event budget plan</li>
    <li><code>POST /api/generate-jewelry</code> — Generate Jewelry budget plan (multipart/form-data or JSON)</li>
    <li><code>GET /api/history</code> — List saved recommendations</li>
    <li><code>GET /api/recommendations-details/:recommendation_id</code> — Load single saved recommendation</li>
    <li><code>GET /api/startup</code> — Application readiness & Gemini AI status</li>
    <li><code>GET /health</code> — Service health check</li>
  </ul>
</body>
</html>`);
  });

  // Optional Auth Endpoints (preserved for API compatibility)
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const { email, password, confirm_password, confirmPassword } = req.body || {};
      const cleanEmail = String(email || '').trim().toLowerCase();
      const rawPassword = String(password || '');
      const rawConfirm =
        confirm_password !== undefined
          ? String(confirm_password)
          : confirmPassword !== undefined
          ? String(confirmPassword)
          : rawPassword;

      if (!cleanEmail || !isValidEmail(cleanEmail)) {
        res.status(400).json({ detail: 'Please enter a valid email address.' });
        return;
      }
      if (!rawPassword || rawPassword.length < 8) {
        res.status(400).json({ detail: 'Password must be at least 8 characters long.' });
        return;
      }
      if (rawPassword !== rawConfirm) {
        res.status(400).json({ detail: 'Passwords do not match. Please confirm your password.' });
        return;
      }

      const existing = db.getUserByEmail(cleanEmail);
      if (existing) {
        res.status(409).json({ detail: 'An account with this email already exists.' });
        return;
      }

      const passwordHash = await bcrypt.hash(rawPassword, 10);
      const user = db.createUser(cleanEmail, passwordHash);
      const token = createToken(user);
      setAuthCookie(res, token);

      res.status(201).json({
        message: 'Registration successful.',
        user: { id: user.id, email: user.email, created_at: user.created_at },
      });
    } catch {
      res.status(500).json({ detail: 'Unable to complete registration.' });
    }
  });

  const handleLogin = async (req: Request, res: Response) => {
    try {
      const rawEmail = req.body?.email || req.body?.username || '';
      const rawPassword = String(req.body?.password || '');
      const cleanEmail = String(rawEmail).trim().toLowerCase();

      if (!cleanEmail || !rawPassword) {
        res.status(400).json({ detail: 'Please enter both your email and password.' });
        return;
      }
      const user = db.getUserByEmail(cleanEmail);
      if (!user || !(await bcrypt.compare(rawPassword, user.password_hash))) {
        res.status(401).json({ detail: 'Invalid email or password.' });
        return;
      }
      const token = createToken(user);
      setAuthCookie(res, token);
      res.json({
        access_token: token,
        token_type: 'bearer',
        user: { id: user.id, email: user.email, created_at: user.created_at },
      });
    } catch {
      res.status(500).json({ detail: 'Login failed.' });
    }
  };

  app.post('/api/auth/login', handleLogin);
  app.post('/api/auth/token', handleLogin);

  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    res.clearCookie(COOKIE_NAME, { path: '/' });
    res.json({ message: 'Logged out successfully.' });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const user = resolveActiveUser(req);
    res.json({
      id: user.id,
      email: user.email,
      created_at: user.created_at,
    });
  });

  // Session Endpoints (always ready, no login barrier required)
  app.get('/api/session-info', (req: Request, res: Response) => {
    const user = resolveActiveUser(req);
    const gemini = getGeminiStatus();
    res.json({
      authenticated: true,
      user: { id: user.id, email: user.email, created_at: user.created_at },
      ai_configured: gemini.configured,
      ai_mode: gemini.aiMode,
      model: gemini.configured ? gemini.model : 'Local Fallback',
    });
  });

  app.get('/api/session-data', (req: Request, res: Response) => {
    const user = resolveActiveUser(req);
    const gemini = getGeminiStatus();
    const historyCount = db.getRecommendationsByUser(user.id).length;
    res.json({
      authenticated: true,
      user: { id: user.id, email: user.email, created_at: user.created_at },
      saved_plans_count: historyCount,
      ai_mode: gemini.aiMode,
      model: gemini.configured ? gemini.model : 'Local Fallback',
    });
  });

  // Planner 1: Home Interior
  app.post('/api/generate-home', async (req: Request, res: Response) => {
    try {
      const user = resolveActiveUser(req);
      const { budget, room_types, items = {}, style, city = 'India', notes = '' } =
        req.body || {};
      const numericBudget = Number(budget);

      if (!numericBudget || isNaN(numericBudget) || numericBudget < 1000) {
        res.status(422).json({
          detail: 'Please enter a valid Home Interior budget of at least ₹1,000.',
        });
        return;
      }

      const rooms = Array.isArray(room_types)
        ? room_types.map((r) => String(r).trim()).filter(Boolean)
        : typeof room_types === 'string' && room_types.trim()
        ? [room_types.trim()]
        : [];

      if (rooms.length === 0) {
        res.status(422).json({
          detail: 'Please select at least one room type for your Home Interior plan.',
        });
        return;
      }

      if (!style || !String(style).trim()) {
        res.status(422).json({ detail: 'Please select an interior style.' });
        return;
      }

      const requestPayload = {
        budget: numericBudget,
        room_types: rooms,
        items,
        style: String(style).trim(),
        city: String(city || 'India').trim() || 'India',
        notes: String(notes || '').trim(),
      };

      const plan = await generateHomePlan(requestPayload);
      const record = db.createRecommendation(
        user.id,
        'home',
        JSON.stringify(requestPayload),
        JSON.stringify(plan)
      );

      res.json({
        ...plan,
        id: record.id,
        created_at: record.created_at,
      });
    } catch {
      res.status(500).json({
        detail: 'Failed to generate Home Interior plan. Please try again.',
      });
    }
  });

  // Planner 2: Party / Event
  app.post('/api/generate-party', async (req: Request, res: Response) => {
    try {
      const user = resolveActiveUser(req);
      const {
        budget,
        guests,
        event_type,
        venue,
        city = 'India',
        food_preference,
        notes = '',
      } = req.body || {};

      const numericBudget = Number(budget);
      const numericGuests = Number(guests);

      if (!numericBudget || isNaN(numericBudget) || numericBudget < 1000) {
        res.status(422).json({
          detail: 'Please enter a valid Party budget of at least ₹1,000.',
        });
        return;
      }

      if (!numericGuests || isNaN(numericGuests) || numericGuests < 1) {
        res.status(422).json({
          detail: 'Please enter a valid number of guests (at least 1).',
        });
        return;
      }

      if (!event_type || !String(event_type).trim()) {
        res.status(422).json({ detail: 'Please select an event type.' });
        return;
      }

      if (!venue || !String(venue).trim()) {
        res.status(422).json({ detail: 'Please select a venue type.' });
        return;
      }

      if (!food_preference || !String(food_preference).trim()) {
        res.status(422).json({ detail: 'Please select a food preference.' });
        return;
      }

      const requestPayload = {
        budget: numericBudget,
        guests: numericGuests,
        event_type: String(event_type).trim(),
        venue: String(venue).trim(),
        city: String(city || 'India').trim() || 'India',
        food_preference: String(food_preference).trim(),
        notes: String(notes || '').trim(),
      };

      const plan = await generatePartyPlan(requestPayload);
      const record = db.createRecommendation(
        user.id,
        'party',
        JSON.stringify(requestPayload),
        JSON.stringify(plan)
      );

      res.json({
        ...plan,
        id: record.id,
        created_at: record.created_at,
      });
    } catch {
      res.status(500).json({
        detail: 'Failed to generate Party plan. Please try again.',
      });
    }
  });

  // Planner 3: Jewelry (supports multipart/form-data with outfit_image OR JSON)
  app.post(
    '/api/generate-jewelry',
    (req: Request, res: Response, next: NextFunction) => {
      const contentType = req.headers['content-type'] || '';
      if (contentType.includes('multipart/form-data')) {
        upload.single('outfit_image')(req, res, (err: unknown) => {
          if (err) {
            res.status(413).json({
              detail: `Outfit image exceeds the ${MAX_UPLOAD_MB} MB maximum size limit.`,
            });
            return;
          }
          next();
        });
      } else {
        next();
      }
    },
    async (req: Request, res: Response) => {
      try {
        const user = resolveActiveUser(req);
        const {
          budget,
          occasion,
          style,
          outfit_color = '',
          metal_preference = 'Any',
          notes = '',
        } = req.body || {};

        const numericBudget = Number(budget);
        if (!numericBudget || isNaN(numericBudget) || numericBudget < 500) {
          res.status(422).json({
            detail: 'Please enter a valid Jewelry budget of at least ₹500.',
          });
          return;
        }

        if (!occasion || !String(occasion).trim()) {
          res.status(422).json({ detail: 'Please select an occasion.' });
          return;
        }

        if (!style || !String(style).trim()) {
          res.status(422).json({ detail: 'Please select a jewelry style.' });
          return;
        }

        const file = req.file;
        let outfitImagePayload: { buffer: Buffer; mimeType: string } | undefined;

        if (file && file.size > 0) {
          if (file.size > MAX_UPLOAD_BYTES) {
            res.status(413).json({
              detail: `Outfit image must be ${MAX_UPLOAD_MB} MB or smaller.`,
            });
            return;
          }
          if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
            res.status(415).json({
              detail: 'Invalid image format. Allowed formats are JPEG, PNG, and WebP.',
            });
            return;
          }
          outfitImagePayload = {
            buffer: file.buffer,
            mimeType: file.mimetype,
          };
        }

        const requestPayload = {
          budget: numericBudget,
          occasion: String(occasion).trim(),
          style: String(style).trim(),
          outfit_color: String(outfit_color || 'Classic Neutral').trim(),
          metal_preference: String(metal_preference || 'Any').trim(),
          notes: String(notes || '').trim(),
          has_outfit_image: Boolean(outfitImagePayload),
        };

        const plan = await generateJewelryPlan(requestPayload, outfitImagePayload);
        const record = db.createRecommendation(
          user.id,
          'jewelry',
          JSON.stringify(requestPayload),
          JSON.stringify(plan)
        );

        res.json({
          ...plan,
          id: record.id,
          created_at: record.created_at,
        });
      } catch {
        res.status(500).json({
          detail: 'Failed to generate Jewelry plan. Please try again.',
        });
      }
    }
  );

  // Explicit Save endpoint
  app.post('/api/recommendations/save', (req: Request, res: Response) => {
    const user = resolveActiveUser(req);
    const { id, planner, request_data, response_data } = req.body || {};
    if (id) {
      const existing = db.getRecommendationById(Number(id));
      if (existing && existing.user_id === user.id) {
        res.json({
          message: 'Recommendation saved to your history.',
          id: existing.id,
          created_at: existing.created_at,
        });
        return;
      }
    }

    const rec = db.createRecommendation(
      user.id,
      String(planner || 'home'),
      JSON.stringify(request_data || {}),
      JSON.stringify(response_data || {})
    );

    res.status(201).json({
      message: 'Recommendation saved to your history.',
      id: rec.id,
      created_at: rec.created_at,
    });
  });

  // History Endpoints
  app.get('/api/history', (req: Request, res: Response) => {
    const user = resolveActiveUser(req);
    const records = db.getRecommendationsByUser(user.id);
    const items = records.map((r) => {
      let reqObj: Record<string, unknown> = {};
      let resObj: Record<string, unknown> = {};
      try {
        reqObj = JSON.parse(r.request_json);
      } catch {
        // ignore
      }
      try {
        resObj = JSON.parse(r.response_json);
      } catch {
        // ignore
      }
      return {
        id: r.id,
        planner: r.planner,
        title: String(resObj.title || `${r.planner.toUpperCase()} Plan`),
        summary: String(resObj.summary || ''),
        budget: Number(resObj.budget || reqObj.budget || 0),
        estimated_total: Number(resObj.estimated_total || 0),
        remaining_budget: Number(resObj.remaining_budget || 0),
        source: String(resObj.source || 'Local Fallback'),
        ai_label: String(resObj.ai_label || 'LOCAL FALLBACK'),
        created_at: r.created_at,
      };
    });

    res.json({ items, total: items.length });
  });

  app.get('/api/recommendations-details/:recommendation_id', (req: Request, res: Response) => {
    const user = resolveActiveUser(req);
    const recId = Number(req.params.recommendation_id);
    if (!recId || isNaN(recId)) {
      res.status(400).json({ detail: 'Invalid recommendation ID.' });
      return;
    }

    const record = db.getRecommendationById(recId);
    if (!record) {
      res.status(404).json({ detail: 'Recommendation not found.' });
      return;
    }

    if (record.user_id !== user.id) {
      res.status(403).json({
        detail: 'You do not have permission to access this recommendation.',
      });
      return;
    }

    let requestData = {};
    let responseData = {};
    try {
      requestData = JSON.parse(record.request_json);
    } catch {
      // ignore
    }
    try {
      responseData = JSON.parse(record.response_json);
    } catch {
      // ignore
    }

    res.json({
      id: record.id,
      user_id: record.user_id,
      planner: record.planner,
      created_at: record.created_at,
      request: requestData,
      recommendation: {
        ...responseData,
        id: record.id,
        created_at: record.created_at,
      },
    });
  });

  return app;
}
