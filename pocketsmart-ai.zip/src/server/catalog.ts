export interface AllocationItem {
  label: string;
  amount: number;
}

export interface RecommendationItem {
  category: string;
  name: string;
  estimated_price: number;
  platform: string;
  rationale: string;
  search_url?: string;
}

export interface RawPlanOutput {
  title: string;
  summary: string;
  estimated_total?: number;
  allocations: AllocationItem[];
  recommendations: RecommendationItem[];
  tips: string[];
}

export interface ValidatedPlanResponse {
  id?: number;
  planner: 'home' | 'party' | 'jewelry';
  source: 'Gemini AI' | 'Local Fallback';
  ai_label: 'AI POWERED' | 'LOCAL FALLBACK';
  model_used: string;
  title: string;
  summary: string;
  budget: number;
  estimated_total: number;
  remaining_budget: number;
  allocations: AllocationItem[];
  recommendations: Required<RecommendationItem>[];
  tips: string[];
  created_at?: string;
}

/**
 * Generates safe search destination URLs for supported platforms:
 * Amazon, Flipkart, IKEA, Swiggy, Zomato, OYO, or Google Search fallback.
 */
export function buildPlatformSearchUrl(platform: string, queryName: string): string {
  const cleanQuery = encodeURIComponent(queryName.trim() || 'budget recommendation');
  const norm = (platform || '').trim().toLowerCase();

  if (norm.includes('amazon')) {
    return `https://www.amazon.in/s?k=${cleanQuery}`;
  }
  if (norm.includes('flipkart')) {
    return `https://www.flipkart.com/search?q=${cleanQuery}`;
  }
  if (norm.includes('ikea')) {
    return `https://www.ikea.com/in/en/search/?q=${cleanQuery}`;
  }
  if (norm.includes('swiggy')) {
    return `https://www.swiggy.com/search?query=${cleanQuery}`;
  }
  if (norm.includes('zomato')) {
    return `https://www.zomato.com/search?q=${cleanQuery}`;
  }
  if (norm.includes('oyo')) {
    return `https://www.oyorooms.com/search?q=${cleanQuery}`;
  }

  const withPlatform = encodeURIComponent(`${queryName.trim()} ${platform.trim()}`.trim());
  return `https://www.google.com/search?q=${withPlatform}`;
}

/**
 * Strictly validates and normalizes a budget plan so that:
 * 1. Every recommendation has a positive integer estimated_price and a safe search_url.
 * 2. The sum of recommendations (estimated_total) NEVER exceeds the user's budget.
 * 3. Remaining budget = budget - estimated_total >= 0.
 * 4. Allocations are positive integers that stay within the user's budget.
 */
export function enforceBudgetControl(
  raw: RawPlanOutput,
  requestedBudget: number,
  planner: 'home' | 'party' | 'jewelry',
  source: 'Gemini AI' | 'Local Fallback',
  modelUsed: string
): ValidatedPlanResponse {
  const budget = Math.max(500, Math.round(Number(requestedBudget) || 10000));

  const rawRecs = Array.isArray(raw.recommendations) ? raw.recommendations : [];
  let sanitizedRecs = rawRecs.map((item) => {
    const price = Math.max(100, Math.round(Number(item.estimated_price) || 500));
    const platform = (item.platform || 'Amazon').trim();
    const name = (item.name || 'Recommended Item').trim();
    return {
      category: (item.category || 'General').trim(),
      name,
      estimated_price: price,
      platform,
      rationale:
        (item.rationale || 'Selected to balance quality and your target budget.').trim(),
      search_url: buildPlatformSearchUrl(platform, name),
    };
  });

  if (sanitizedRecs.length === 0) {
    const defaultPrice = Math.round(budget * 0.8);
    sanitizedRecs = [
      {
        category: 'Core Selection',
        name: `${planner.charAt(0).toUpperCase() + planner.slice(1)} Essentials Bundle`,
        estimated_price: defaultPrice,
        platform: planner === 'party' ? 'Zomato' : 'Amazon',
        rationale: 'Core budget-conscious package tailored to your target spend.',
        search_url: buildPlatformSearchUrl(
          planner === 'party' ? 'Zomato' : 'Amazon',
          `${planner} essentials`
        ),
      },
    ];
  }

  let sumPrices = sanitizedRecs.reduce((acc, r) => acc + r.estimated_price, 0);

  // If the sum of recommendation prices exceeds the user's requested budget,
  // scale them down proportionally so estimated_total is strictly <= budget (targeting ~90-94% of budget).
  if (sumPrices > budget) {
    const targetMax = Math.floor(budget * 0.92);
    const scaleFactor = targetMax / sumPrices;
    sanitizedRecs = sanitizedRecs.map((r) => {
      const scaled = Math.max(50, Math.floor((r.estimated_price * scaleFactor) / 50) * 50);
      return {
        ...r,
        estimated_price: scaled,
      };
    });
    sumPrices = sanitizedRecs.reduce((acc, r) => acc + r.estimated_price, 0);

    // Final safety clamp if rounding still pushes sumPrices above budget
    if (sumPrices > budget && sanitizedRecs.length > 0) {
      const overflow = sumPrices - budget;
      sanitizedRecs[0].estimated_price = Math.max(
        50,
        sanitizedRecs[0].estimated_price - overflow
      );
      sumPrices = sanitizedRecs.reduce((acc, r) => acc + r.estimated_price, 0);
    }
  }

  const estimatedTotal = sumPrices;
  const remainingBudget = Math.max(0, budget - estimatedTotal);

  // Validate and normalize allocations
  const rawAllocations = Array.isArray(raw.allocations) ? raw.allocations : [];
  let allocations: AllocationItem[] = rawAllocations
    .filter((a) => a && a.label)
    .map((a) => ({
      label: String(a.label).trim(),
      amount: Math.max(0, Math.round(Number(a.amount) || 0)),
    }));

  const allocSum = allocations.reduce((acc, a) => acc + a.amount, 0);
  if (allocations.length === 0 || allocSum > budget || allocSum === 0) {
    // Derive clean allocations directly from category breakdown + Buffer
    const categoryTotals = new Map<string, number>();
    for (const rec of sanitizedRecs) {
      categoryTotals.set(
        rec.category,
        (categoryTotals.get(rec.category) || 0) + rec.estimated_price
      );
    }
    allocations = Array.from(categoryTotals.entries()).map(([label, amount]) => ({
      label,
      amount,
    }));
    if (remainingBudget > 0) {
      allocations.push({
        label: 'Contingency Buffer',
        amount: remainingBudget,
      });
    }
  }

  const rawTips = Array.isArray(raw.tips) ? raw.tips.filter(Boolean) : [];
  const tips =
    rawTips.length >= 3
      ? rawTips.slice(0, 8)
      : [
          'Compare dimensions and specifications across at least two platforms before placing orders.',
          `Keep your ₹${remainingBudget.toLocaleString('en-IN')} remaining buffer untouched for delivery, installation, or last-minute adjustments.`,
          'Verify return windows, warranty terms, and seller ratings on each marketplace.',
          'Bundle deliveries where possible to reduce shipping and handling charges.',
        ];

  return {
    planner,
    source,
    ai_label: source === 'Gemini AI' ? 'AI POWERED' : 'LOCAL FALLBACK',
    model_used: source === 'Gemini AI' ? modelUsed : 'Local Fallback',
    title: (raw.title || `Smart ${planner.toUpperCase()} Budget Plan`).trim(),
    summary: (
      raw.summary ||
      `Curated ${planner} plan within your ₹${budget.toLocaleString('en-IN')} budget with ₹${remainingBudget.toLocaleString('en-IN')} preserved as contingency buffer.`
    ).trim(),
    budget,
    estimated_total: estimatedTotal,
    remaining_budget: remainingBudget,
    allocations,
    recommendations: sanitizedRecs,
    tips,
  };
}
