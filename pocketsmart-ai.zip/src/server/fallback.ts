import {
  enforceBudgetControl,
  RawPlanOutput,
  ValidatedPlanResponse,
} from './catalog.ts';

export interface HomePlanRequest {
  budget: number;
  room_types: string[];
  items?: Record<string, unknown>;
  style: string;
  city: string;
  notes?: string;
}

export interface PartyPlanRequest {
  budget: number;
  guests: number;
  event_type: string;
  venue: string;
  city: string;
  food_preference: string;
  notes?: string;
}

export interface JewelryPlanRequest {
  budget: number;
  occasion: string;
  style: string;
  outfit_color: string;
  metal_preference: string;
  notes?: string;
  has_outfit_image?: boolean;
}

export function generateHomeFallback(req: HomePlanRequest): ValidatedPlanResponse {
  const budget = Math.max(1000, Number(req.budget) || 50000);
  const rooms =
    Array.isArray(req.room_types) && req.room_types.length > 0
      ? req.room_types
      : ['Living Room'];
  const styleCap =
    (req.style || 'Modern').charAt(0).toUpperCase() + (req.style || 'Modern').slice(1);
  const city = (req.city || 'India').trim();

  const usableBudget = Math.floor(budget * 0.88);
  const furnitureShare = Math.floor(usableBudget * 0.45);
  const lightingShare = Math.floor(usableBudget * 0.18);
  const decorShare = Math.floor(usableBudget * 0.2);
  const storageShare = usableBudget - furnitureShare - lightingShare - decorShare;
  const bufferShare = budget - usableBudget;

  const primaryRoom = rooms[0];
  const secondaryRoom = rooms[1] || rooms[0];

  const raw: RawPlanOutput = {
    title: `${styleCap} ${rooms.join(' & ')} Interior Plan (${city})`,
    summary: `A practical ${styleCap.toLowerCase()} home interior allocation for ${rooms.join(
      ', '
    )} in ${city}, keeping estimated purchases at ₹${usableBudget.toLocaleString(
      'en-IN'
    )} with ₹${bufferShare.toLocaleString('en-IN')} reserved in buffer.`,
    estimated_total: usableBudget,
    allocations: [
      { label: 'Furniture', amount: furnitureShare },
      { label: 'Lighting', amount: lightingShare },
      { label: 'Decor & Soft Furnishings', amount: decorShare },
      { label: 'Modular Storage', amount: storageShare },
      { label: 'Buffer', amount: bufferShare },
    ],
    recommendations: [
      {
        category: 'Furniture',
        name: `${styleCap} ${primaryRoom} Primary Seating / Anchor Piece`,
        estimated_price: Math.floor(furnitureShare * 0.65),
        platform: 'IKEA',
        rationale: `Anchors the ${primaryRoom.toLowerCase()} with durable ${styleCap.toLowerCase()} lines while leaving headroom for accent pieces.`,
      },
      {
        category: 'Furniture',
        name: `Compact ${secondaryRoom} Multipurpose Table`,
        estimated_price: furnitureShare - Math.floor(furnitureShare * 0.65),
        platform: 'Flipkart',
        rationale: `Space-saving surface tailored for ${secondaryRoom.toLowerCase()} utility.`,
      },
      {
        category: 'Lighting',
        name: `Warm Ambient LED Floor & Pendant Lamp Set (${styleCap})`,
        estimated_price: lightingShare,
        platform: 'Amazon',
        rationale: `Layered warm 3000K lighting elevates ${styleCap.toLowerCase()} textures without costly electrical rewiring.`,
      },
      {
        category: 'Decor',
        name: `Coordinated ${styleCap} Woven Rug, Cushions & Wall Art Set`,
        estimated_price: decorShare,
        platform: 'Amazon',
        rationale: `Ties together the color palette across ${rooms.join(' and ')}${
          req.notes ? ` (${req.notes.slice(0, 60)})` : ''
        }.`,
      },
      {
        category: 'Storage',
        name: `Vertical Modular Shelving & Concealed Organizer Unit`,
        estimated_price: storageShare,
        platform: 'IKEA',
        rationale: `Maximizes vertical floor-to-ceiling storage capacity to keep rooms clutter-free.`,
      },
    ],
    tips: [
      'Measure doorways, staircases, and wall clearances with masking tape on the floor before ordering large furniture.',
      `Retain your ₹${bufferShare.toLocaleString('en-IN')} buffer for carpenter assembly, delivery fees, and curtain hardware.`,
      'Order fabric swatches or smaller decor items first to verify color accuracy under your room lighting.',
      'Compare assembly-included listings on Flipkart and IKEA to avoid surprise installation expenses.',
      `Prioritize anchor furniture for ${primaryRoom} first before adding secondary decorative accents.`,
    ],
  };

  return enforceBudgetControl(raw, budget, 'home', 'Local Fallback', 'Local Fallback');
}

export function generatePartyFallback(req: PartyPlanRequest): ValidatedPlanResponse {
  const budget = Math.max(1000, Number(req.budget) || 30000);
  const guests = Math.max(1, Number(req.guests) || 25);
  const eventCap =
    (req.event_type || 'Birthday').charAt(0).toUpperCase() +
    (req.event_type || 'Birthday').slice(1);
  const venueCap =
    (req.venue || 'Home').charAt(0).toUpperCase() + (req.venue || 'Home').slice(1);
  const foodPref = (req.food_preference || 'Mixed').toUpperCase();
  const city = (req.city || 'India').trim();

  const usableBudget = Math.floor(budget * 0.88);
  const foodShare = Math.floor(usableBudget * 0.48);
  const venueShare = Math.floor(usableBudget * 0.24);
  const decorShare = Math.floor(usableBudget * 0.16);
  const entertainmentShare = usableBudget - foodShare - venueShare - decorShare;
  const bufferShare = budget - usableBudget;

  const raw: RawPlanOutput = {
    title: `${eventCap} Celebration Plan for ${guests} Guests (${city})`,
    summary: `Complete ${eventCap.toLowerCase()} budget blueprint for ${guests} guests at a ${venueCap.toLowerCase()} venue in ${city} with ${foodPref.toLowerCase()} menu options and ₹${bufferShare.toLocaleString(
      'en-IN'
    )} contingency buffer.`,
    estimated_total: usableBudget,
    allocations: [
      { label: 'Food & Catering', amount: foodShare },
      { label: 'Venue & Seating Setup', amount: venueShare },
      { label: 'Theme Decoration', amount: decorShare },
      { label: 'Music & Party Supplies', amount: entertainmentShare },
      { label: 'Buffer', amount: bufferShare },
    ],
    recommendations: [
      {
        category: 'Food & Catering',
        name: `${foodPref} Party Catering Platter & Starters (${guests} Guests)`,
        estimated_price: Math.floor(foodShare * 0.78),
        platform: 'Zomato',
        rationale: `Covers main course and starters for ${guests} guests at ~₹${Math.round(
          (foodShare * 0.78) / guests
        )} per plate.`,
      },
      {
        category: 'Desserts & Beverages',
        name: `Celebration Cake, Welcome Drinks & Dessert Box`,
        estimated_price: foodShare - Math.floor(foodShare * 0.78),
        platform: 'Swiggy',
        rationale: `Dedicated allocation for centerpiece ${eventCap.toLowerCase()} cake and chilled refreshments.`,
      },
      {
        category: 'Venue & Hospitality',
        name: `${venueCap} Event Space / Guest Seating & Tableware Arrangement`,
        estimated_price: venueShare,
        platform: req.venue?.toLowerCase() === 'home' ? 'Amazon' : 'OYO',
        rationale:
          req.venue?.toLowerCase() === 'home'
            ? 'Covers premium disposable tableware, chafing dishes, and extra guest seating for a home event.'
            : `Estimated booking and setup allocation for a ${venueCap.toLowerCase()} gathering in ${city}.`,
      },
      {
        category: 'Decoration',
        name: `${eventCap} Photo Backdrop, Warm Fairy Lights & Table Centerpieces`,
        estimated_price: decorShare,
        platform: 'Amazon',
        rationale: `High-impact focal backdrop for guest photos without overspending on full-room draping.`,
      },
      {
        category: 'Entertainment & Favors',
        name: `Portable Party Speaker Setup & Curated Return Gift Pouches`,
        estimated_price: entertainmentShare,
        platform: 'Flipkart',
        rationale: `Keeps guest energy high and provides thoughtful takeaways for ${guests} attendees.`,
      },
    ],
    tips: [
      `Confirm final guest headcount (${guests} guests) 48 hours before placing bulk food orders on Zomato or Swiggy.`,
      `Keep ₹${bufferShare.toLocaleString('en-IN')} aside for extra ice, serving platters, and last-minute guest additions.`,
      'Focus decoration budget on one well-lit photo backdrop corner and the dining table.',
      'Order non-perishable decor and tableware at least 5 days in advance to avoid express delivery surcharges.',
    ],
  };

  return enforceBudgetControl(raw, budget, 'party', 'Local Fallback', 'Local Fallback');
}

export function generateJewelryFallback(req: JewelryPlanRequest): ValidatedPlanResponse {
  const budget = Math.max(1000, Number(req.budget) || 25000);
  const occasionCap =
    (req.occasion || 'Wedding').charAt(0).toUpperCase() +
    (req.occasion || 'Wedding').slice(1);
  const styleCap =
    (req.style || 'Elegant').charAt(0).toUpperCase() + (req.style || 'Elegant').slice(1);
  const metalCap = (req.metal_preference || 'Gold').trim() || 'Gold';
  const outfitColor = (req.outfit_color || 'Emerald Green').trim() || 'Classic Neutral';

  const usableBudget = Math.floor(budget * 0.88);
  const necklaceShare = Math.floor(usableBudget * 0.46);
  const earringsShare = Math.floor(usableBudget * 0.28);
  const wristShare = Math.floor(usableBudget * 0.18);
  const careShare = usableBudget - necklaceShare - earringsShare - wristShare;
  const bufferShare = budget - usableBudget;

  const raw: RawPlanOutput = {
    title: `${styleCap} ${metalCap} Jewelry Pairing for ${occasionCap}`,
    summary: `Balanced ${styleCap.toLowerCase()} jewelry ensemble in ${metalCap} curated to complement your ${outfitColor} outfit for a ${occasionCap.toLowerCase()}${
      req.has_outfit_image ? ' (incorporating your uploaded outfit styling cues)' : ''
    }, keeping ₹${bufferShare.toLocaleString('en-IN')} in reserve.`,
    estimated_total: usableBudget,
    allocations: [
      { label: 'Statement Necklace / Pendant', amount: necklaceShare },
      { label: 'Coordinated Earrings', amount: earringsShare },
      { label: 'Bracelet / Bangles & Ring', amount: wristShare },
      { label: 'Storage & Care Kit', amount: careShare },
      { label: 'Buffer', amount: bufferShare },
    ],
    recommendations: [
      {
        category: 'Neckwear',
        name: `${styleCap} ${metalCap}-Tone Necklace Accented for ${outfitColor} Attire`,
        estimated_price: necklaceShare,
        platform: 'Amazon',
        rationale: `Creates a refined focal point against ${outfitColor} fabric for ${occasionCap.toLowerCase()} wear.`,
      },
      {
        category: 'Earrings',
        name: `Matching ${styleCap} ${metalCap} Drop / Stud Earrings`,
        estimated_price: earringsShare,
        platform: 'Flipkart',
        rationale: `Frames the face harmoniously without competing with the neckline silhouette.`,
      },
      {
        category: 'Wristwear',
        name: `${metalCap} Textured Cuff Bracelet / Bangle Set`,
        estimated_price: wristShare,
        platform: 'Amazon',
        rationale: `Completes the ensemble with balanced ${metalCap.toLowerCase()} luster on the wrist.`,
      },
      {
        category: 'Care & Organization',
        name: `Anti-Tarnish Velvet Lined Jewelry Travel & Storage Box`,
        estimated_price: careShare,
        platform: 'Flipkart',
        rationale: `Protects plating, clasps, and stones from humidity and scratches between occasions.`,
      },
    ],
    tips: [
      'Check hallmark certifications (such as BIS 916 for gold or 925 sterling silver stamp) when purchasing precious metals.',
      `Pair ${outfitColor} outfits with ${metalCap} finishes that contrast cleanly with the neckline embroidery.`,
      'Verify clasp weight, earring post comfort, and return policies before finalizing online jewelry orders.',
      'Store pieces in individual anti-tarnish zip pouches and apply perfume before putting on jewelry.',
    ],
  };

  return enforceBudgetControl(raw, budget, 'jewelry', 'Local Fallback', 'Local Fallback');
}
