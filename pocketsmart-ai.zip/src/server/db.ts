import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

export interface UserRecord {
  id: number;
  email: string;
  password_hash: string;
  created_at: string;
}

export interface RecommendationRecord {
  id: number;
  user_id: number;
  planner: string;
  request_json: string;
  response_json: string;
  created_at: string;
}

const DB_FILE_PATH = path.resolve(process.cwd(), 'pocketsmart.db');
const JSON_FALLBACK_PATH = path.resolve(process.cwd(), 'pocketsmart.fallback.json');

interface SqliteAdapter {
  engine: 'sqlite' | 'file-sqlite-fallback';
  createUser(email: string, passwordHash: string): UserRecord;
  getUserByEmail(email: string): UserRecord | undefined;
  getUserById(id: number): UserRecord | undefined;
  createRecommendation(
    userId: number,
    planner: string,
    requestJson: string,
    responseJson: string
  ): RecommendationRecord;
  getRecommendationsByUser(userId: number): RecommendationRecord[];
  getRecommendationById(id: number): RecommendationRecord | undefined;
  resetForTests(): void;
}

function createSqliteAdapter(): SqliteAdapter {
  try {
    const nodeSqlite = require('node:sqlite');
    const db = new nodeSqlite.DatabaseSync(DB_FILE_PATH);

    db.exec('PRAGMA foreign_keys = ON;');
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS recommendations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        planner TEXT NOT NULL,
        request_json TEXT NOT NULL,
        response_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `);

    return {
      engine: 'sqlite',
      createUser(email: string, passwordHash: string): UserRecord {
        const normalizedEmail = email.trim().toLowerCase();
        const createdAt = new Date().toISOString();
        const stmt = db.prepare(
          'INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, ?)'
        );
        const result = stmt.run(normalizedEmail, passwordHash, createdAt);
        return {
          id: Number(result.lastInsertRowid),
          email: normalizedEmail,
          password_hash: passwordHash,
          created_at: createdAt,
        };
      },
      getUserByEmail(email: string): UserRecord | undefined {
        const normalizedEmail = email.trim().toLowerCase();
        const stmt = db.prepare(
          'SELECT id, email, password_hash, created_at FROM users WHERE email = ?'
        );
        const row = stmt.get(normalizedEmail) as UserRecord | undefined;
        return row ? { ...row, id: Number(row.id) } : undefined;
      },
      getUserById(id: number): UserRecord | undefined {
        const stmt = db.prepare(
          'SELECT id, email, password_hash, created_at FROM users WHERE id = ?'
        );
        const row = stmt.get(id) as UserRecord | undefined;
        return row ? { ...row, id: Number(row.id) } : undefined;
      },
      createRecommendation(
        userId: number,
        planner: string,
        requestJson: string,
        responseJson: string
      ): RecommendationRecord {
        const createdAt = new Date().toISOString();
        const stmt = db.prepare(
          'INSERT INTO recommendations (user_id, planner, request_json, response_json, created_at) VALUES (?, ?, ?, ?, ?)'
        );
        const result = stmt.run(userId, planner, requestJson, responseJson, createdAt);
        return {
          id: Number(result.lastInsertRowid),
          user_id: userId,
          planner,
          request_json: requestJson,
          response_json: responseJson,
          created_at: createdAt,
        };
      },
      getRecommendationsByUser(userId: number): RecommendationRecord[] {
        const stmt = db.prepare(
          'SELECT id, user_id, planner, request_json, response_json, created_at FROM recommendations WHERE user_id = ? ORDER BY id DESC'
        );
        const rows = stmt.all(userId) as RecommendationRecord[];
        return rows.map((r) => ({
          ...r,
          id: Number(r.id),
          user_id: Number(r.user_id),
        }));
      },
      getRecommendationById(id: number): RecommendationRecord | undefined {
        const stmt = db.prepare(
          'SELECT id, user_id, planner, request_json, response_json, created_at FROM recommendations WHERE id = ?'
        );
        const row = stmt.get(id) as RecommendationRecord | undefined;
        return row
          ? { ...row, id: Number(row.id), user_id: Number(row.user_id) }
          : undefined;
      },
      resetForTests(): void {
        db.exec('DELETE FROM recommendations; DELETE FROM users;');
      },
    };
  } catch {
    // Fallback persistent store if node:sqlite is unavailable
    interface StoreData {
      users: UserRecord[];
      recommendations: RecommendationRecord[];
      nextUserId: number;
      nextRecId: number;
    }

    const loadStore = (): StoreData => {
      try {
        if (fs.existsSync(JSON_FALLBACK_PATH)) {
          return JSON.parse(fs.readFileSync(JSON_FALLBACK_PATH, 'utf-8')) as StoreData;
        }
      } catch {
        // ignore
      }
      return { users: [], recommendations: [], nextUserId: 1, nextRecId: 1 };
    };

    const saveStore = (data: StoreData) => {
      fs.writeFileSync(JSON_FALLBACK_PATH, JSON.stringify(data, null, 2), 'utf-8');
    };

    return {
      engine: 'file-sqlite-fallback',
      createUser(email: string, passwordHash: string): UserRecord {
        const store = loadStore();
        const normalizedEmail = email.trim().toLowerCase();
        if (store.users.some((u) => u.email === normalizedEmail)) {
          throw new Error('UNIQUE constraint failed: users.email');
        }
        const user: UserRecord = {
          id: store.nextUserId++,
          email: normalizedEmail,
          password_hash: passwordHash,
          created_at: new Date().toISOString(),
        };
        store.users.push(user);
        saveStore(store);
        return user;
      },
      getUserByEmail(email: string): UserRecord | undefined {
        const store = loadStore();
        return store.users.find((u) => u.email === email.trim().toLowerCase());
      },
      getUserById(id: number): UserRecord | undefined {
        const store = loadStore();
        return store.users.find((u) => u.id === id);
      },
      createRecommendation(
        userId: number,
        planner: string,
        requestJson: string,
        responseJson: string
      ): RecommendationRecord {
        const store = loadStore();
        if (!store.users.some((u) => u.id === userId)) {
          throw new Error('FOREIGN KEY constraint failed');
        }
        const rec: RecommendationRecord = {
          id: store.nextRecId++,
          user_id: userId,
          planner,
          request_json: requestJson,
          response_json: responseJson,
          created_at: new Date().toISOString(),
        };
        store.recommendations.push(rec);
        saveStore(store);
        return rec;
      },
      getRecommendationsByUser(userId: number): RecommendationRecord[] {
        const store = loadStore();
        return store.recommendations
          .filter((r) => r.user_id === userId)
          .sort((a, b) => b.id - a.id);
      },
      getRecommendationById(id: number): RecommendationRecord | undefined {
        const store = loadStore();
        return store.recommendations.find((r) => r.id === id);
      },
      resetForTests(): void {
        saveStore({ users: [], recommendations: [], nextUserId: 1, nextRecId: 1 });
      },
    };
  }
}

export const db = createSqliteAdapter();
