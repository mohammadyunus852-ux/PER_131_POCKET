import React, { useEffect, useState } from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import {
  BudgetPlanResponse,
  formatInr,
  HistorySummaryItem,
} from '../types/pocketsmart';
import { RecommendationResult } from './RecommendationResult';

interface HistoryViewProps {
  onStartPlanning: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ onStartPlanning }) => {
  const [items, setItems] = useState<HistorySummaryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<BudgetPlanResponse | null>(
    null
  );
  const [loadingDetailId, setLoadingDetailId] = useState<number | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/history', {
        credentials: 'include',
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail || 'Could not load your saved recommendations.');
        return;
      }
      setItems(Array.isArray(data.items) ? data.items : []);
    } catch {
      setError('Network error while loading your saved history.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleViewDetail = async (id: number) => {
    setLoadingDetailId(id);
    setError(null);
    try {
      const res = await fetch(`/api/recommendations-details/${id}`, {
        credentials: 'include',
      });
      const data = await res.json();
      if (!res.ok || !data.recommendation) {
        setError(data.detail || 'Unable to open saved recommendation.');
        return;
      }
      setSelectedPlan(data.recommendation as BudgetPlanResponse);
    } catch {
      setError('Network error while loading recommendation details.');
    } finally {
      setLoadingDetailId(null);
    }
  };

  if (selectedPlan) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setSelectedPlan(null)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            Back to Saved History
          </button>
        </div>

        <RecommendationResult
          plan={selectedPlan}
          onViewHistory={() => setSelectedPlan(null)}
        />
      </div>
    );
  }

  return (
    <section aria-labelledby="history-heading" className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <h1
              id="history-heading"
              className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display"
            >
              Saved Budget Plans
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Review your previous Home, Party, and Jewelry recommendations.
            </p>
          </div>

          <button
            type="button"
            onClick={onStartPlanning}
            className="px-4 py-2.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            + Create New Plan
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="mt-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs font-medium text-rose-700"
          >
            {error}
          </div>
        )}

        {loading ? (
          <div className="py-12 flex items-center justify-center gap-3 text-slate-500 text-sm">
            <Loader2 className="w-5 h-5 animate-spin text-teal-600" />
            Loading your saved history…
          </div>
        ) : items.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <p className="text-base font-semibold text-slate-800">
              No saved plans yet.
            </p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Generate a Home Interior, Party, or Jewelry budget plan to save and revisit it here.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={onStartPlanning}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              >
                Start Planning
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-6 divide-y divide-slate-200">
            {items.map((item) => (
              <div
                key={item.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/70 px-3 rounded-xl transition-colors"
              >
                <div className="space-y-1">
                  {/* Unboxed clean metadata with typographic separators */}
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-medium">
                    <span className="text-teal-700 font-semibold uppercase">
                      {item.planner}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{item.source}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      {new Date(item.created_at).toLocaleString()}
                    </span>
                  </div>

                  <h2 className="text-base font-bold text-slate-900">
                    {item.title}
                  </h2>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 font-mono tabular-nums">
                    <span>Budget: {formatInr(item.budget)}</span>
                    <span aria-hidden="true">·</span>
                    <span>Estimated Total: {formatInr(item.estimated_total)}</span>
                    <span aria-hidden="true">·</span>
                    <span>Remaining: {formatInr(item.remaining_budget)}</span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={loadingDetailId === item.id}
                  onClick={() => handleViewDetail(item.id)}
                  className="px-4 py-2 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {loadingDetailId === item.id ? 'Opening...' : 'View'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
