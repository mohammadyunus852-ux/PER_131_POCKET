import React, { useState } from 'react';
import { BookmarkCheck, ExternalLink, History } from 'lucide-react';
import { BudgetPlanResponse, formatInr } from '../types/pocketsmart';

interface RecommendationResultProps {
  plan: BudgetPlanResponse;
  onViewHistory: () => void;
}

export const RecommendationResult: React.FC<RecommendationResultProps> = ({
  plan,
  onViewHistory,
}) => {
  const [savedNotice, setSavedNotice] = useState(Boolean(plan.id));
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch('/api/recommendations/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          id: plan.id,
          planner: plan.planner,
          response_data: plan,
        }),
      });
      setSavedNotice(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section
      aria-labelledby="plan-result-title"
      className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-8"
    >
      {/* Header & Source Status */}
      <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="space-y-2 max-w-3xl">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
            <span
              className={
                plan.source === 'Gemini AI' ? 'text-teal-700' : 'text-amber-700'
              }
            >
              {plan.ai_label}
            </span>
            <span aria-hidden="true" className="text-slate-400">
              ·
            </span>
            <span className="text-slate-600">{plan.source}</span>
            <span aria-hidden="true" className="text-slate-400">
              ·
            </span>
            <span className="text-slate-500 uppercase">{plan.planner} PLANNER</span>
            {plan.created_at && (
              <>
                <span aria-hidden="true" className="text-slate-400">
                  ·
                </span>
                <span className="text-slate-500 font-mono">
                  {new Date(plan.created_at).toLocaleString()}
                </span>
              </>
            )}
          </div>

          <h2
            id="plan-result-title"
            className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 font-display"
          >
            {plan.title}
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            {plan.summary}
          </p>
        </div>

        {/* Save & History Actions */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <BookmarkCheck className="w-4 h-4" aria-hidden="true" />
            {saving
              ? 'Saving...'
              : savedNotice
              ? 'Saved in History'
              : 'Save Recommendation'}
          </button>

          <button
            type="button"
            onClick={onViewHistory}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <History className="w-4 h-4" aria-hidden="true" />
            View History
          </button>
        </div>
      </div>

      {/* Three Core Budget Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-slate-50 border border-slate-200">
          <div className="text-xs font-medium text-slate-500">Budget</div>
          <div className="text-2xl sm:text-3xl font-bold text-slate-900 font-mono tabular-nums mt-1">
            {formatInr(plan.budget)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Requested maximum spend</div>
        </div>

        <div className="p-5 rounded-xl bg-teal-50/50 border border-teal-200">
          <div className="text-xs font-medium text-teal-800">Estimated Total</div>
          <div className="text-2xl sm:text-3xl font-bold text-teal-900 font-mono tabular-nums mt-1">
            {formatInr(plan.estimated_total)}
          </div>
          <div className="text-xs text-teal-700 mt-1">
            {Math.round((plan.estimated_total / Math.max(1, plan.budget)) * 100)}% of budget
            (Estimated prices)
          </div>
        </div>

        <div className="p-5 rounded-xl bg-slate-50 border border-slate-200">
          <div className="text-xs font-medium text-slate-500">Remaining</div>
          <div className="text-2xl sm:text-3xl font-bold text-slate-900 font-mono tabular-nums mt-1">
            {formatInr(plan.remaining_budget)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Unallocated contingency buffer</div>
        </div>
      </div>

      {/* Budget Allocations */}
      <div className="space-y-4">
        <div className="flex items-baseline justify-between">
          <h3 className="text-lg font-bold text-slate-900 font-display">
            Budget Allocation
          </h3>
          <span className="text-xs text-slate-500 font-mono tabular-nums">
            Total Budget: {formatInr(plan.budget)}
          </span>
        </div>

        <div className="space-y-3">
          {plan.allocations.map((alloc, idx) => {
            const pct = Math.min(
              100,
              Math.max(3, Math.round((alloc.amount / Math.max(1, plan.budget)) * 100))
            );
            return (
              <div key={`${alloc.label}-${idx}`} className="space-y-1.5">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium text-slate-800">{alloc.label}</span>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {formatInr(alloc.amount)}
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-teal-600 rounded-full transition-all duration-300"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recommendations Grid */}
      <div className="space-y-4 pt-2 border-t border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
          <h3 className="text-lg font-bold text-slate-900 font-display">
            Recommendations
          </h3>
          <span className="text-xs text-slate-500">
            Estimated prices · Search destinations open external marketplace queries
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plan.recommendations.map((rec, idx) => (
            <article
              key={`${rec.name}-${idx}`}
              className="p-5 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                {/* Clean unboxed metadata with typographic separators */}
                <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                  <span className="text-teal-700 font-semibold">{rec.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{rec.platform}</span>
                </div>

                <h4 className="text-base font-bold text-slate-900">{rec.name}</h4>

                <div className="text-sm font-mono font-semibold text-slate-900 tabular-nums">
                  Estimated: {formatInr(rec.estimated_price)}
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  &ldquo;{rec.rationale}&rdquo;
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Search on {rec.platform}
                </span>
                <a
                  href={rec.search_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-700 hover:text-teal-800 hover:underline whitespace-nowrap shrink-0"
                >
                  Open Search ↗
                  <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Smart Budget Tips */}
      <div className="space-y-3 pt-2 border-t border-slate-200">
        <h3 className="text-lg font-bold text-slate-900 font-display">
          Smart Budget Tips
        </h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {plan.tips.map((tip, idx) => (
            <li
              key={idx}
              className="text-sm text-slate-700 leading-relaxed flex items-start gap-2.5"
            >
              <span className="font-mono text-xs font-semibold text-teal-700 mt-0.5 tabular-nums">
                0{idx + 1}.
              </span>
              <span>{tip}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};
