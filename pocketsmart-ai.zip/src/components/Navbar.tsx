import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { AppView } from '../types/pocketsmart';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (view: AppView) => {
    onNavigate(view);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-slate-200">
      <div className="max-w-[1280px] mx-auto px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Title, single text element */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            handleNav('dashboard');
          }}
          className="text-xl font-extrabold tracking-tight text-slate-900 font-display whitespace-nowrap shrink-0"
        >
          PocketSmart AI
        </a>

        {/* Zone 2: Primary Navigation Links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
        >
          <button
            type="button"
            onClick={() => handleNav('dashboard')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              currentView === 'dashboard'
                ? 'text-slate-900 font-semibold underline underline-offset-8 decoration-2 decoration-teal-600'
                : ''
            }`}
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => handleNav('planners')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              currentView === 'planners'
                ? 'text-slate-900 font-semibold underline underline-offset-8 decoration-2 decoration-teal-600'
                : ''
            }`}
          >
            Planners
          </button>
          <button
            type="button"
            onClick={() => handleNav('history')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              currentView === 'history'
                ? 'text-slate-900 font-semibold underline underline-offset-8 decoration-2 decoration-teal-600'
                : ''
            }`}
          >
            History
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="hidden md:flex items-center gap-3">
          <button
            type="button"
            onClick={() => handleNav('planners')}
            className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Start Planning
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          type="button"
          onClick={() => setMobileMenuOpen((prev) => !prev)}
          aria-label="Toggle navigation menu"
          className="md:hidden p-2 text-slate-700 hover:text-slate-900 rounded-lg cursor-pointer"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-6 py-4 space-y-3">
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={() => handleNav('dashboard')}
              className="text-left py-2 text-sm font-semibold text-slate-800 cursor-pointer"
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => handleNav('planners')}
              className="text-left py-2 text-sm font-semibold text-slate-800 cursor-pointer"
            >
              Planners
            </button>
            <button
              type="button"
              onClick={() => handleNav('history')}
              className="text-left py-2 text-sm font-semibold text-slate-800 cursor-pointer"
            >
              History
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
