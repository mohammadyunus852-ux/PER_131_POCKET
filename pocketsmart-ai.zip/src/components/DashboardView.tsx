import React from 'react';
import { ArrowRight, History, Home, PartyPopper, Gem } from 'lucide-react';
import { PlannerType, SessionInfo } from '../types/pocketsmart';

interface DashboardViewProps {
  session: SessionInfo;
  onSelectPlanner: (planner: PlannerType) => void;
  onViewHistory: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  session,
  onSelectPlanner,
  onViewHistory,
}) => {
  return (
    <div className="space-y-10">
      {/* Hero Section */}
      <section className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-10 shadow-xs">
        <div className="max-w-3xl space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="text-teal-700 font-semibold">POCKETSMART AI</span>
            <span aria-hidden="true">·</span>
            <span>
              {session.ai_configured
                ? `AI: ${session.model} (Gemini AI)`
                : 'AI: Local Fallback'}
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 font-display text-balance">
            Your budget, turned into a plan.
          </h1>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
            Use PocketSmart AI for home interiors, parties, and jewelry planning with
            budget-aware recommendations.
          </p>

          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onSelectPlanner('home')}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Start Planning
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onViewHistory}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <History className="w-4 h-4" aria-hidden="true" />
              View History
            </button>
          </div>
        </div>
      </section>

      {/* Three Planner Cards */}
      <section aria-labelledby="planners-heading" className="space-y-4">
        <div className="flex items-baseline justify-between">
          <h2
            id="planners-heading"
            className="text-xl font-bold text-slate-900 font-display"
          >
            Choose a Budget Planner
          </h2>
          <span className="text-xs text-slate-500">
            All estimates strictly capped at or below your ₹ budget
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Home */}
          <article className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-xs hover:border-slate-300 transition-colors">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
                <Home className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-display">
                Home
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Room-by-room furniture, lighting, decor and storage ideas.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => onSelectPlanner('home')}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              >
                Plan Home
              </button>
            </div>
          </article>

          {/* Card 2: Party */}
          <article className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-xs hover:border-slate-300 transition-colors">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                <PartyPopper className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-display">
                Party
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Food, venue, decoration and entertainment allocations.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => onSelectPlanner('party')}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              >
                Plan Party
              </button>
            </div>
          </article>

          {/* Card 3: Jewelry */}
          <article className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-xs hover:border-slate-300 transition-colors">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center">
                <Gem className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-display">
                Jewelry
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Occasion and style matching with optional outfit-image input.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => onSelectPlanner('jewelry')}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
              >
                Plan Jewelry
              </button>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
};
