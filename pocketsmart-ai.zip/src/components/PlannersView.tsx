import React, { useState } from 'react';
import { Loader2, Upload } from 'lucide-react';
import {
  BudgetPlanResponse,
  PlannerType,
  SessionInfo,
} from '../types/pocketsmart';
import { RecommendationResult } from './RecommendationResult';

interface PlannersViewProps {
  session: SessionInfo;
  activeTab: PlannerType;
  onTabChange: (tab: PlannerType) => void;
  onViewHistory: () => void;
}

const HOME_ROOMS = [
  'Living Room',
  'Bedroom',
  'Kitchen',
  'Dining Room',
  'Bathroom',
  'Balcony',
  'Office',
];

const HOME_STYLES = [
  'Modern',
  'Minimal',
  'Traditional',
  'Bohemian',
  'Contemporary',
];

const PARTY_EVENTS = [
  'Birthday',
  'Wedding',
  'Anniversary',
  'Engagement',
  'Baby Shower',
  'Corporate Event',
  'Festival',
];

const PARTY_VENUES = ['Home', 'Hall', 'Outdoor', 'Restaurant'];

const PARTY_FOOD = ['Vegetarian', 'Non-Vegetarian', 'Mixed', 'Vegan'];

const JEWELRY_OCCASIONS = [
  'Wedding',
  'Engagement',
  'Party',
  'Festival',
  'Casual',
  'Anniversary',
];

const JEWELRY_STYLES = ['Elegant', 'Minimal', 'Traditional', 'Statement'];

const JEWELRY_METALS = ['Gold', 'Silver', 'Rose Gold', 'Platinum', 'Any'];

export const PlannersView: React.FC<PlannersViewProps> = ({
  session,
  activeTab,
  onTabChange,
  onViewHistory,
}) => {
  // Home Form State
  const [homeBudget, setHomeBudget] = useState<string>('100000');
  const [selectedRooms, setSelectedRooms] = useState<string[]>([
    'Living Room',
    'Bedroom',
  ]);
  const [homeStyle, setHomeStyle] = useState<string>('Modern');
  const [homeCity, setHomeCity] = useState<string>('India');
  const [homeNotes, setHomeNotes] = useState<string>('');

  // Party Form State
  const [partyBudget, setPartyBudget] = useState<string>('50000');
  const [partyGuests, setPartyGuests] = useState<string>('30');
  const [partyEvent, setPartyEvent] = useState<string>('Birthday');
  const [partyVenue, setPartyVenue] = useState<string>('Home');
  const [partyCity, setPartyCity] = useState<string>('India');
  const [partyFood, setPartyFood] = useState<string>('Mixed');
  const [partyNotes, setPartyNotes] = useState<string>('');

  // Jewelry Form State
  const [jewelryBudget, setJewelryBudget] = useState<string>('35000');
  const [jewelryOccasion, setJewelryOccasion] = useState<string>('Wedding');
  const [jewelryStyle, setJewelryStyle] = useState<string>('Elegant');
  const [outfitColor, setOutfitColor] = useState<string>('Emerald Green');
  const [metalPreference, setMetalPreference] = useState<string>('Gold');
  const [jewelryNotes, setJewelryNotes] = useState<string>('');
  const [outfitFile, setOutfitFile] = useState<File | null>(null);
  const [outfitPreviewUrl, setOutfitPreviewUrl] = useState<string | null>(null);

  // Generation & Result State
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPlan, setGeneratedPlan] = useState<BudgetPlanResponse | null>(
    null
  );

  const toggleRoom = (room: string) => {
    setSelectedRooms((prev) =>
      prev.includes(room) ? prev.filter((r) => r !== room) : [...prev, room]
    );
  };

  const handleOutfitFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const file = e.target.files?.[0] || null;
    if (!file) {
      setOutfitFile(null);
      setOutfitPreviewUrl(null);
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      setError('Invalid image format. Allowed formats are JPEG, PNG, and WebP.');
      e.target.value = '';
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError('Outfit image exceeds the 5 MB maximum file size.');
      e.target.value = '';
      return;
    }

    setOutfitFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setOutfitPreviewUrl(typeof reader.result === 'string' ? reader.result : null);
    };
    reader.readAsDataURL(file);
  };

  const handleHomeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const budgetNum = Number(homeBudget);
    if (!budgetNum || budgetNum < 1000) {
      setError('Please enter a valid Home Interior budget of at least ₹1,000.');
      return;
    }
    if (selectedRooms.length === 0) {
      setError('Please select at least one room.');
      return;
    }

    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate-home', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          budget: budgetNum,
          room_types: selectedRooms,
          items: {},
          style: homeStyle.toLowerCase(),
          city: homeCity.trim() || 'India',
          notes: homeNotes.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail || 'Could not generate Home Interior plan.');
        return;
      }
      setGeneratedPlan(data as BudgetPlanResponse);
    } catch {
      setError('Network error while generating your Home plan. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePartySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const budgetNum = Number(partyBudget);
    const guestsNum = Number(partyGuests);
    if (!budgetNum || budgetNum < 1000) {
      setError('Please enter a valid Party budget of at least ₹1,000.');
      return;
    }
    if (!guestsNum || guestsNum < 1) {
      setError('Please enter at least 1 guest.');
      return;
    }

    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate-party', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          budget: budgetNum,
          guests: guestsNum,
          event_type: partyEvent.toLowerCase(),
          venue: partyVenue.toLowerCase(),
          city: partyCity.trim() || 'India',
          food_preference: partyFood.toLowerCase(),
          notes: partyNotes.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail || 'Could not generate Party plan.');
        return;
      }
      setGeneratedPlan(data as BudgetPlanResponse);
    } catch {
      setError('Network error while generating your Party plan. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleJewelrySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const budgetNum = Number(jewelryBudget);
    if (!budgetNum || budgetNum < 500) {
      setError('Please enter a valid Jewelry budget of at least ₹500.');
      return;
    }

    setIsGenerating(true);
    try {
      const formData = new FormData();
      formData.append('budget', String(budgetNum));
      formData.append('occasion', jewelryOccasion.toLowerCase());
      formData.append('style', jewelryStyle.toLowerCase());
      formData.append('outfit_color', outfitColor.trim() || 'Classic Neutral');
      formData.append('metal_preference', metalPreference.toLowerCase());
      formData.append('notes', jewelryNotes.trim());
      if (outfitFile) {
        formData.append('outfit_image', outfitFile);
      }

      const res = await fetch('/api/generate-jewelry', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail || 'Could not generate Jewelry plan.');
        return;
      }
      setGeneratedPlan(data as BudgetPlanResponse);
    } catch {
      setError('Network error while generating your Jewelry plan. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Planner Tabs & AI Status Indicator */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          {/* Three Planner Tabs */}
          <div
            role="tablist"
            aria-label="Budget Planners"
            className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-xl"
          >
            {(['home', 'party', 'jewelry'] as PlannerType[]).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={activeTab === tab}
                onClick={() => {
                  onTabChange(tab);
                  setError(null);
                }}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === tab
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab === 'home' ? 'Home' : tab === 'party' ? 'Party' : 'Jewelry'}
              </button>
            ))}
          </div>

          {/* Required AI Status Indicator */}
          <div className="text-xs font-mono text-slate-600">
            {session.ai_configured ? (
              <span>
                AI: <strong className="text-teal-700">{session.model}</strong> (Gemini AI)
              </span>
            ) : (
              <span>
                AI: <strong className="text-amber-700">Local Fallback</strong>
              </span>
            )}
          </div>
        </div>

        {/* Form 1: HOME INTERIOR PLANNER */}
        {activeTab === 'home' && (
          <form onSubmit={handleHomeSubmit} noValidate className="mt-6 space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                Home Interior Planner
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Room-by-room furniture, lighting, decor and storage allocations in Indian Rupees (₹).
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label
                  htmlFor="home-budget"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Budget (₹ INR)
                </label>
                <input
                  id="home-budget"
                  type="number"
                  min={1000}
                  step={500}
                  required
                  disabled={isGenerating}
                  value={homeBudget}
                  onChange={(e) => setHomeBudget(e.target.value)}
                  placeholder="100000"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="home-style"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Style
                </label>
                <select
                  id="home-style"
                  disabled={isGenerating}
                  value={homeStyle}
                  onChange={(e) => setHomeStyle(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {HOME_STYLES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="home-city"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  City
                </label>
                <input
                  id="home-city"
                  type="text"
                  disabled={isGenerating}
                  value={homeCity}
                  onChange={(e) => setHomeCity(e.target.value)}
                  placeholder="India"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-2">
                Rooms (Select one or more)
              </span>
              <div className="flex flex-wrap gap-2">
                {HOME_ROOMS.map((room) => {
                  const active = selectedRooms.includes(room);
                  return (
                    <button
                      key={room}
                      type="button"
                      disabled={isGenerating}
                      onClick={() => toggleRoom(room)}
                      className={`px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? 'bg-teal-600 text-white border-teal-600'
                          : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {room}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label
                htmlFor="home-notes"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Notes (Room dimensions, must-have items, color preferences, special requirements)
              </label>
              <textarea
                id="home-notes"
                rows={3}
                disabled={isGenerating}
                value={homeNotes}
                onChange={(e) => setHomeNotes(e.target.value)}
                placeholder="e.g., 12x15 ft living room, compact 3-seater sofa, warm oak finish, rental-friendly lighting..."
                className="w-full rounded-xl border border-slate-300 p-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
              />
            </div>

            {error && (
              <div
                role="alert"
                className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-700"
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isGenerating}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
            >
              {isGenerating && <Loader2 className="w-4 h-4 animate-spin" />}
              {isGenerating ? 'Generating your plan…' : 'Generate Home Plan'}
            </button>
          </form>
        )}

        {/* Form 2: PARTY PLANNER */}
        {activeTab === 'party' && (
          <form onSubmit={handlePartySubmit} noValidate className="mt-6 space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                Party &amp; Event Planner
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Food, venue, decoration and entertainment allocations in Indian Rupees (₹).
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label
                  htmlFor="party-budget"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Budget (₹ INR)
                </label>
                <input
                  id="party-budget"
                  type="number"
                  min={1000}
                  step={500}
                  required
                  disabled={isGenerating}
                  value={partyBudget}
                  onChange={(e) => setPartyBudget(e.target.value)}
                  placeholder="50000"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="party-guests"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Number of Guests
                </label>
                <input
                  id="party-guests"
                  type="number"
                  min={1}
                  required
                  disabled={isGenerating}
                  value={partyGuests}
                  onChange={(e) => setPartyGuests(e.target.value)}
                  placeholder="30"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="party-event"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Event Type
                </label>
                <select
                  id="party-event"
                  disabled={isGenerating}
                  value={partyEvent}
                  onChange={(e) => setPartyEvent(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {PARTY_EVENTS.map((ev) => (
                    <option key={ev} value={ev}>
                      {ev}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="party-venue"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Venue
                </label>
                <select
                  id="party-venue"
                  disabled={isGenerating}
                  value={partyVenue}
                  onChange={(e) => setPartyVenue(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {PARTY_VENUES.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="party-city"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  City
                </label>
                <input
                  id="party-city"
                  type="text"
                  disabled={isGenerating}
                  value={partyCity}
                  onChange={(e) => setPartyCity(e.target.value)}
                  placeholder="India"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="party-food"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Food Preference
                </label>
                <select
                  id="party-food"
                  disabled={isGenerating}
                  value={partyFood}
                  onChange={(e) => setPartyFood(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {PARTY_FOOD.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label
                htmlFor="party-notes"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Notes (Additional requirements, theme colors, dietary requests)
              </label>
              <textarea
                id="party-notes"
                rows={3}
                disabled={isGenerating}
                value={partyNotes}
                onChange={(e) => setPartyNotes(e.target.value)}
                placeholder="e.g., Pastel balloon backdrop, live acoustic playlist, kid-friendly snack station..."
                className="w-full rounded-xl border border-slate-300 p-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
              />
            </div>

            {error && (
              <div
                role="alert"
                className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-700"
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isGenerating}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
            >
              {isGenerating && <Loader2 className="w-4 h-4 animate-spin" />}
              {isGenerating ? 'Generating your plan…' : 'Generate Party Plan'}
            </button>
          </form>
        )}

        {/* Form 3: JEWELRY PLANNER */}
        {activeTab === 'jewelry' && (
          <form onSubmit={handleJewelrySubmit} noValidate className="mt-6 space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                Jewelry Planner
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Occasion and style matching with optional outfit-image color/style cue analysis.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label
                  htmlFor="jewelry-budget"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Budget (₹ INR)
                </label>
                <input
                  id="jewelry-budget"
                  type="number"
                  min={500}
                  step={500}
                  required
                  disabled={isGenerating}
                  value={jewelryBudget}
                  onChange={(e) => setJewelryBudget(e.target.value)}
                  placeholder="35000"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="jewelry-occasion"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Occasion
                </label>
                <select
                  id="jewelry-occasion"
                  disabled={isGenerating}
                  value={jewelryOccasion}
                  onChange={(e) => setJewelryOccasion(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {JEWELRY_OCCASIONS.map((occ) => (
                    <option key={occ} value={occ}>
                      {occ}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="jewelry-style"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Style
                </label>
                <select
                  id="jewelry-style"
                  disabled={isGenerating}
                  value={jewelryStyle}
                  onChange={(e) => setJewelryStyle(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {JEWELRY_STYLES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="outfit-color"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Outfit Color
                </label>
                <input
                  id="outfit-color"
                  type="text"
                  disabled={isGenerating}
                  value={outfitColor}
                  onChange={(e) => setOutfitColor(e.target.value)}
                  placeholder="e.g., Emerald Green, Ivory & Gold, Navy Blue"
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="metal-preference"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Metal Preference
                </label>
                <select
                  id="metal-preference"
                  disabled={isGenerating}
                  value={metalPreference}
                  onChange={(e) => setMetalPreference(e.target.value)}
                  className="w-full h-11 rounded-xl border border-slate-300 px-3.5 text-sm text-slate-900 bg-white focus:border-teal-600 focus:outline-none cursor-pointer"
                >
                  {JEWELRY_METALS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="outfit-image"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Outfit Image (Optional · JPEG, PNG, WebP · Max 5 MB)
                </label>
                <label
                  htmlFor="outfit-image"
                  className="flex items-center justify-between h-11 px-3.5 rounded-xl border border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 text-xs text-slate-700 cursor-pointer"
                >
                  <span className="truncate">
                    {outfitFile ? outfitFile.name : 'Upload outfit photo...'}
                  </span>
                  <Upload className="w-4 h-4 text-slate-500 shrink-0" />
                  <input
                    id="outfit-image"
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    disabled={isGenerating}
                    onChange={handleOutfitFileChange}
                    className="sr-only"
                  />
                </label>
                <p className="text-[11px] text-slate-500 mt-1">
                  Privacy: Only visible colors and style cues are analyzed. Never identifies the person.
                </p>
              </div>
            </div>

            {outfitPreviewUrl && (
              <div className="flex items-center gap-4 p-3 rounded-xl bg-slate-50 border border-slate-200">
                <img
                  src={outfitPreviewUrl}
                  alt="Uploaded outfit preview for color and style analysis"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-lg object-cover border border-slate-300"
                />
                <div className="text-xs text-slate-600">
                  <div className="font-semibold text-slate-900">
                    Outfit Image Ready for Style &amp; Color Analysis
                  </div>
                  <div>{outfitFile?.name}</div>
                </div>
              </div>
            )}

            <div>
              <label
                htmlFor="jewelry-notes"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Notes (Neckline cut, stone preferences, allergy considerations)
              </label>
              <textarea
                id="jewelry-notes"
                rows={3}
                disabled={isGenerating}
                value={jewelryNotes}
                onChange={(e) => setJewelryNotes(e.target.value)}
                placeholder="e.g., Boat-neck silk saree, lightweight earrings preferred, pearl accents..."
                className="w-full rounded-xl border border-slate-300 p-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
              />
            </div>

            {error && (
              <div
                role="alert"
                className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-700"
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isGenerating}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
            >
              {isGenerating && <Loader2 className="w-4 h-4 animate-spin" />}
              {isGenerating ? 'Generating your plan…' : 'Generate Jewelry Plan'}
            </button>
          </form>
        )}
      </div>

      {/* Loading Indicator Banner */}
      {isGenerating && (
        <div
          role="status"
          aria-live="polite"
          className="bg-white border border-slate-200 rounded-2xl p-6 flex items-center gap-4 shadow-xs"
        >
          <Loader2 className="w-6 h-6 animate-spin text-teal-600 shrink-0" />
          <div>
            <div className="text-sm font-bold text-slate-900">
              Generating your plan…
            </div>
            <p className="text-xs text-slate-500">
              Calculating category allocations, verifying budget ceiling, and building platform search links.
            </p>
          </div>
        </div>
      )}

      {/* Generated Recommendation Result */}
      {generatedPlan && !isGenerating && (
        <RecommendationResult
          plan={generatedPlan}
          onViewHistory={onViewHistory}
        />
      )}
    </div>
  );
};
