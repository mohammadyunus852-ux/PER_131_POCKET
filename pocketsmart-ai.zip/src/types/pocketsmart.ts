export type PlannerType = 'home' | 'party' | 'jewelry';

export type AppView = 'auth' | 'dashboard' | 'planners' | 'history';

export interface User {
  id: number;
  email: string;
  created_at: string;
}

export interface SessionInfo {
  authenticated: boolean;
  user: User | null;
  ai_configured: boolean;
  ai_mode: 'Gemini AI' | 'Local Fallback';
  model: string;
}

export interface AllocationItem {
  label: string;
  amount: number;
}

export interface RecommendationItem {
  category: string;
  name: string;
  estimated_price: number;
  platform: string;
  rationale: string;
  search_url: string;
}

export interface BudgetPlanResponse {
  id?: number;
  planner: PlannerType;
  source: 'Gemini AI' | 'Local Fallback';
  ai_label: 'AI POWERED' | 'LOCAL FALLBACK';
  model_used: string;
  title: string;
  summary: string;
  budget: number;
  estimated_total: number;
  remaining_budget: number;
  allocations: AllocationItem[];
  recommendations: RecommendationItem[];
  tips: string[];
  created_at?: string;
}

export interface HistorySummaryItem {
  id: number;
  planner: PlannerType;
  title: string;
  summary: string;
  budget: number;
  estimated_total: number;
  remaining_budget: number;
  source: 'Gemini AI' | 'Local Fallback';
  ai_label: string;
  created_at: string;
}

export function formatInr(amount: number): string {
  const num = Math.round(Number(amount) || 0);
  return `₹${num.toLocaleString('en-IN')}`;
}
