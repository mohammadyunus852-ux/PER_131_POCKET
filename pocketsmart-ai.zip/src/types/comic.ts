export type SettingOption =
  | 'Forest'
  | 'School'
  | 'City'
  | 'Space'
  | 'Fantasy World'
  | 'Cyberpunk Metropolis'
  | 'Underwater Kingdom'
  | 'Ancient Temple'
  | 'Steampunk Airship'
  | 'Cozy Village';

export type StoryToneOption =
  | 'Funny'
  | 'Dramatic'
  | 'Light-hearted'
  | 'Poetic'
  | 'Adventure'
  | 'Mystery'
  | 'Heroic'
  | 'Whimsical';

export type ArtStyleOption =
  | 'Anime'
  | 'Comic Book'
  | 'Pixel Art'
  | 'Realistic'
  | 'Cartoon'
  | 'Graphic Novel Noir'
  | 'Watercolor Storybook'
  | 'Retro Golden Age';

export interface ComicInput {
  prompt: string;
  characterName: string;
  setting: SettingOption;
  tone: StoryToneOption;
  artStyle: ArtStyleOption;
}

export interface CharacterProfile {
  name: string;
  summary: string;
  visualAppearance: string;
  clothingAndFeatures: string;
  consistencyPrompt: string;
}

export interface Dialogue {
  character: string;
  text: string;
  emotion?: string;
}

export interface ComicPanelOutline {
  panel_number: number;
  narrative_stage: string;
  title: string;
  summary: string;
  key_visual_beat: string;
}

export interface ComicPanel {
  panel_number: number;
  narrative_stage: string;
  title: string;
  scene_description: string;
  narration: string;
  dialogue: Dialogue[];
  camera_composition?: string;
  lighting?: string;
  image_prompt: string;
  imageUrl?: string;
  imageSource?: 'gemini-image' | 'gemini-svg-fallback' | 'procedural-fallback';
  isRegeneratingImage?: boolean;
}

export interface ComicStory {
  id: string;
  createdAt: string;
  storyTitle: string;
  input: ComicInput;
  characterProfile: CharacterProfile;
  outline: ComicPanelOutline[];
  panels: ComicPanel[];
  imageLimitationNotice?: string | null;
}

export type GenerationPhase =
  | 'idle'
  | 'creating_story'
  | 'designing_panels'
  | 'writing_dialogue'
  | 'creating_illustrations'
  | 'finishing_comic'
  | 'completed'
  | 'error';

export interface GenerationState {
  phase: GenerationPhase;
  statusMessage: string;
  progressPercent: number;
  completedPanels: number;
  totalPanels: number;
  partialTitle?: string;
  partialCharacter?: CharacterProfile;
  partialOutline?: ComicPanelOutline[];
  error?: string | null;
}
