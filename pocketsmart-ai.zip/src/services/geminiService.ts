import {
  CharacterProfile,
  ComicInput,
  ComicPanel,
  ComicPanelOutline,
  ComicStory,
  GenerationState,
} from '../types/comic';

interface OutlineApiResponse {
  storyTitle: string;
  characterProfile: CharacterProfile;
  outline: ComicPanelOutline[];
  error?: string;
}

interface PanelsApiResponse {
  panels: ComicPanel[];
  error?: string;
}

interface IllustrateApiResponse {
  imageUrl: string;
  source: 'gemini-image' | 'gemini-svg-fallback' | 'procedural-fallback';
  limitationNotice?: string | null;
  error?: string;
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit,
  timeoutMs = 60000
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } catch (err: unknown) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('The request timed out while communicating with the AI service. Please try again.');
    }
    throw new Error('Network error while connecting to the ComicCraft server. Please check your connection and try again.');
  } finally {
    clearTimeout(timer);
  }
}

export async function generateSinglePanelIllustration(params: {
  panel: ComicPanel;
  input: ComicInput;
  characterProfile: CharacterProfile;
}): Promise<IllustrateApiResponse> {
  const { panel, input, characterProfile } = params;
  const response = await fetchWithTimeout(
    '/api/comic/illustrate',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        panel_number: panel.panel_number,
        title: panel.title,
        scene_description: panel.scene_description,
        image_prompt: panel.image_prompt,
        characterName: input.characterName,
        characterSummary: characterProfile.consistencyPrompt || characterProfile.summary,
        setting: input.setting,
        tone: input.tone,
        artStyle: input.artStyle,
      }),
    },
    65000
  );

  const data = (await response.json()) as IllustrateApiResponse;
  if (!response.ok || !data.imageUrl) {
    throw new Error(data.error || `Failed to generate illustration for Panel ${panel.panel_number}.`);
  }
  return data;
}

export async function generateCompleteComic(
  input: ComicInput,
  onProgress: (state: GenerationState) => void
): Promise<ComicStory> {
  // Stage 1: Creating story outline & character profile
  onProgress({
    phase: 'creating_story',
    statusMessage: 'Creating your story...',
    progressPercent: 12,
    completedPanels: 0,
    totalPanels: 5,
  });

  const outlineRes = await fetchWithTimeout(
    '/api/comic/outline',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    },
    60000
  );

  const outlineData = (await outlineRes.json()) as OutlineApiResponse;
  if (!outlineRes.ok) {
    throw new Error(
      outlineData.error || 'Something went wrong while creating your story outline. Please try again.'
    );
  }

  // Stage 2: Designing 5-panel structure
  onProgress({
    phase: 'designing_panels',
    statusMessage: 'Designing comic panels...',
    progressPercent: 28,
    completedPanels: 0,
    totalPanels: 5,
    partialTitle: outlineData.storyTitle,
    partialCharacter: outlineData.characterProfile,
    partialOutline: outlineData.outline,
  });

  // Short visual beat so the user sees the designed outline & character profile before dialogue finishes
  await new Promise((r) => setTimeout(r, 350));

  // Stage 3: Writing detailed narration & dialogue
  onProgress({
    phase: 'writing_dialogue',
    statusMessage: 'Writing dialogue...',
    progressPercent: 42,
    completedPanels: 0,
    totalPanels: 5,
    partialTitle: outlineData.storyTitle,
    partialCharacter: outlineData.characterProfile,
    partialOutline: outlineData.outline,
  });

  const panelsRes = await fetchWithTimeout(
    '/api/comic/panels',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...input,
        storyTitle: outlineData.storyTitle,
        characterProfile: outlineData.characterProfile,
        outline: outlineData.outline,
      }),
    },
    65000
  );

  const panelsData = (await panelsRes.json()) as PanelsApiResponse;
  if (!panelsRes.ok || !panelsData.panels || panelsData.panels.length === 0) {
    throw new Error(
      panelsData.error || 'Something went wrong while writing your comic panels and dialogue. Please try again.'
    );
  }

  // Stage 4: Creating illustrations for all 5 panels
  onProgress({
    phase: 'creating_illustrations',
    statusMessage: 'Creating illustrations (Panel 1 of 5)...',
    progressPercent: 54,
    completedPanels: 0,
    totalPanels: 5,
    partialTitle: outlineData.storyTitle,
    partialCharacter: outlineData.characterProfile,
    partialOutline: outlineData.outline,
  });

  const illustratedPanels: ComicPanel[] = [];
  let limitationNotice: string | null = null;

  for (let i = 0; i < panelsData.panels.length; i++) {
    const panel = panelsData.panels[i];
    onProgress({
      phase: 'creating_illustrations',
      statusMessage: `Creating illustrations (Panel ${i + 1} of ${panelsData.panels.length})...`,
      progressPercent: 54 + Math.round(((i + 0.5) / panelsData.panels.length) * 38),
      completedPanels: i,
      totalPanels: panelsData.panels.length,
      partialTitle: outlineData.storyTitle,
      partialCharacter: outlineData.characterProfile,
      partialOutline: outlineData.outline,
    });

    const imgResult = await generateSinglePanelIllustration({
      panel,
      input,
      characterProfile: outlineData.characterProfile,
    });

    if (imgResult.limitationNotice && !limitationNotice) {
      limitationNotice = imgResult.limitationNotice;
    }

    illustratedPanels.push({
      ...panel,
      imageUrl: imgResult.imageUrl,
      imageSource: imgResult.source,
    });
  }

  // Stage 5: Finishing comic
  onProgress({
    phase: 'finishing_comic',
    statusMessage: 'Finishing your comic...',
    progressPercent: 98,
    completedPanels: 5,
    totalPanels: 5,
    partialTitle: outlineData.storyTitle,
    partialCharacter: outlineData.characterProfile,
    partialOutline: outlineData.outline,
  });

  await new Promise((r) => setTimeout(r, 300));

  return {
    id: `comic_${Date.now()}`,
    createdAt: new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }),
    storyTitle: outlineData.storyTitle,
    input,
    characterProfile: outlineData.characterProfile,
    outline: outlineData.outline,
    panels: illustratedPanels,
    imageLimitationNotice: limitationNotice,
  };
}
